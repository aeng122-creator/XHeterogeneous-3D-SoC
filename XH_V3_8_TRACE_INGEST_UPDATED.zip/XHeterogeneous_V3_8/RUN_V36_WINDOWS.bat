@echo off
cd /d "%~dp0"
py -3 -m unittest discover -s tests -v
if errorlevel 1 exit /b 1
py -3 -m sim.run_v36_study --cycles 12000 --out results/v3_6_study.json
pause
