# X-Heterogeneous V3.4 — Intel Arc 140V-class GPU reference: executed test report

**Status:** Synthetic discrete-cycle cache/mesh proxy + standalone power/thermal and *analytic* GPU roofline.
**NOT:** actual Intel Arc silicon, gem5, GPGPU-Sim, physical GPU shaders, 8K render benchmark, true silicon power/IPC measurement.

## New configuration

- Lower silicon tier: 8 P-cores / 16 threads + 32 E-cores / 32 threads; L1=3 MiB; L2=48 MiB.
- Upper tier: GPU with **8 Intel Xe2-like Xe cores, 64 vector engines, 1.95 GHz reference maximum**, NPU, L3 CPU 96 MiB + GPU 16 MiB.
- Intel reference data is not equivalent to a licensed or fully implemented Intel GPU.
- GPU and CPU/NPU now use **the same quad-channel DDR5 controller**; former hypothetical VRAM endpoint removed.
- Quad DDR5-5600 ideal 179.2 GB/s; network model's sustained rate is **assumed** 140 GB/s.
- GPU power is **assumed**: 25 W moderate, 30 W extreme, 0.7 W at idle (NOT Intel measurements).
- 120 W sustained package target, **170 W preventive**, **176 W modeled predictive target**, **180 W boost hard limit**; all hypothetical hardware controls.

## Watt-demand proxy, including the chip's other domains

| Test | Unthrottled demand | Maximum applied in 5-second model | 5-s mean | End state |
|---|---:|---:|---:|---|
| Idle | 10.600 W | 10.600 W | 10.600 W | BOOST |
| Moderate | 132.309 W | 132.309 W | 132.309 W | BOOST |
| Extreme (all domains) | 185.509 W | 176.000 W | 144.000 W | SUSTAINED |

Compared to the former **90 W GPU hypothesis**, the 30 W GPU hypothesis lowers extreme all-domain *requested* power from 245.509 W to 185.509 W. The 170 W preventive guard still caps to 176 W under a fully charged boost budget, with the controller later enforcing 120 W sustained. The power controller is NOT coupled to simulated network/gpu pipeline clocks and has no calibrated PDK-based voltage-frequency model.

## Same traces, changed GPU memory architecture

| Load | V3.3 GPU P95 | V3.4 GPU P95 | V3.3 P CPU P95 | V3.4 P CPU P95 | Main difference |
|---|---:|---:|---:|---:|---|
| light, 0.25 intensity, 657 requests | 120 cycles | 143 cycles | 163 cycles | 168 cycles | GPU joins CPU/NPU DDR queue |
| heavy, 1.25 intensity, 3829 requests | 130 cycles | 5443 cycles | 3667 cycles | 5420 cycles | shared DDR queue overload |

This increase in modeled GPU memory latency is **not** a benchmark or assertion that real Intel Arc iGPU is slower by the same ratio. It reflects one simplistic serialized memory queue, open-loop injection faster than its modeled service, a shifted endpoint layout, and no real backpressure. The model does not implement bandwidth arbitration accurately between all requesters.

At intensity 1.25, the shared DDR queue services ~0.2365 MB of line fills from a 0.720 us injection window; demanded bandwidth is on the order of 328 GB/s, above 140 GB/s sustainable assumption. Therefore backlog forms and queue latency balloons. Here MB refers to decimal megabytes and line requests, not full memory command traffic.

## Theoretical 8K roofline only

8K = 7,680 × 4,320 = 33,177,600 pixels. Assuming **idealized Xe2 shader configuration** (16 FP32 lanes per vector, 2 FLOPs/FMA), model peak = 3.994 TFLOPS (hypothetical). For the roofline, 55% effective utilization is assumed and GPU receives 45% of the 140 GB/s DDR proxy = 63 GB/s.

| Artificial per-pixel work | Optimistic LOWER bound on frame time | Optimistic UPPER bound on FPS |
|---|---:|---:|
| 1,000 FP32 ops + 32 bytes | 16.852 ms | 59.34 |
| 20,000 FP32 ops + 128 bytes | 302.098 ms | 3.31 |

**These are not measured 8K render speeds**. Texture cache behavior, scene data, ray tracing, graphics pipeline, display, drivers, and real kernel issue rates are not simulated. FP32 execution peak is explicitly an assumed bound, not a certified 140V specification.

## Verification

- 24/24 unit tests passed.
- Four mesh modes completed the same synthetic traces; no NoC deadlocks in this **unbounded queue** model.
- GPU cache misses use shared DDR5, with no remaining VRAM memory endpoint.
- Existing tests retained for 170 W guard / 180 W boost clamp / 120 W sustained budget / sensor failure / temperature fault.
- All results are reproducible by running `python -m sim.run_xe2_study --cycles 1800 --intensity 1.25` and tests from the project root. Light-load replay is `python sim/model.py --cycles 1600 --intensity 0.25`; legacy V3.3 baselines are embedded under `results/v3_3_*baseline.json`.

## Intel sources

- https://www.intel.com/content/www/us/en/products/sku/240957/intel-core-ultra-7-processor-258v-12m-cache-up-to-4-80-ghz/specifications.html
- https://www.intel.com/content/www/us/en/docs/oneapi/optimization-guide-gpu/2025-2/intel-xe-gpu-architecture.html
