# X-Heterogeneous V3.6 — Controlled preliminary stress report

**NOT** silicon measurement, gem5/GPGPU-Sim or 3D-ICE output. Baseline V3.5 and V3.6 are compared with **the same controlled synthetic request trace**, fixed 2.5GHz reference clock, byte-credit link/DDR/HBM queues and hypothetical codec settings.

## Key bandwidth assumptions
- Quad DDR5-6400, 4 × 64 bits: 204.8GB/s peak; **153.6GB/s assumed sustained**.
- One HBM3 stack, 1024 bits × 6.4Gbps: **819.2GB/s peak**, **573.44GB/s assumed sustained** at 70% efficiency.
- HBM is memory-side L4 cache; misses are backed by DDR. It is not a replacement for 112MiB SRAM L3. No fabricated hit measurements.

## Fixed 263.62GB/s offered logical traffic, synthetic compression
- Synthetic low-entropy GPU lines: 45% selected for 2:1 compression, high-entropy GPU lines bypass 14-cycle codec; combined assumed physical demand: **236.51GB/s**.
- V3.5 LPDDR5X x256 baseline, no HBM: E-P95 **5252 cycles**, GPU-P95 **141 cycles**, DDR pending peak **2410**. This baseline uses the new model's synthetic trace, NOT the earlier V3.5 study's recorded P95 values.

| HBM Hit setting | Observed HBM hits | DDR pending peak | E P95 cycles | GPU P95 cycles | Extra drain cycles |
|---|---:|---:|---:|---:|---:|
| 0% | 0.0% | 6556 | 10603 | 2274 | 6665 |
| 25% | 24.4% | 1918 | 5393 | 122 | 2271 |
| 45% | 44.4% | 29 | 151 | 116 | 110 |
| 50% | 49.5% | 19 | 126 | 114 | 110 |
| 55% | 54.5% | 15 | 114 | 114 | 102 |
| 70% | 69.9% | 10 | 104 | 111 | 98 |

**Conclusion:** With fixed synthetic request inputs, DDR saturation disappears near **45% observed HBM hit** when low-entropy GPU compression is active, but at ~25% hits DDR queues remain congested and E-Cores experience very long wait. HBM hit rate is *controlled*, not actually predicted from a working set.

## Adaptive compression bypass
| Mode | Physical offered GB/s | DDR peak queue | GPU P95 |
|---|---:|---:|---:|
| Always uncompressed | 263.61 | 18 | 108 cycles |
| Adaptive bypass on random | 236.51 | 15 | 114 cycles |

Compression saved bytes under this synthetic mixture but **increased GPU P95** in this below-saturation HBM scenario due to the **assumed 14-cycle codec latency**. The controller must bypass whenever codec cost exceeds bandwidth savings.

## Cross-tier vertical-gateway sensitivity (conceptual)
- One central gateway, 2 packets injected every cycle, 1 pkt/cycle gateway service: P95 **2851 cycles**.
- Four independent gateways, adaptive least-queued selection: P95 **1 cycle**.
- GPU -> same-upper-tier L3 local exchange: **NO TSV**; illustrative 2-cycle local hop.

**Not a full flit-level test of Escape VCs**, only a gateway queue sensitivity. A real design must prove deadlock freedom and timing.

## Thermal RC for stepped cold plate
2s boost 180W then 120W sustained, both totals **include hypothetical HBM 12W boost / 8W sustained**; coolant 30°C; all resistances/capacitances assumed:

| Time | Mode | CPU node °C | GPU-L3 node °C | HBM node °C | Coldplate node °C |
|---|---|---:|---:|---:|---:|
| 2.0s | boost | 40.59 | 37.94 | 32.31 | 31.77 |
| 20.0s | sustained | 52.81 | 49.18 | 42.48 | 40.55 |
| 120.0s | sustained | 54.87 | 51.09 | 44.56 | 42.0 |

This is a **lumped RC example** not CFD, not 3D-ICE, and it excludes per-core local hotspot gradients, contact stress and thermally coupled PHY effects. 180W continuous for 120s is *not permitted by the boost policy*; any constant 180W case in JSON is only thermal sensitivity.

## Remaining engineering gates before design sign-off
1. Real HBM hit-rate distribution from workload, read/write memory ordering, backpressure and cache replacement, and 16/24GB package geometry.
2. Memory-space isolation + full CPU/GPU coherent directory and non-inclusive ownership; ECC and dirty writeback.
3. NoC link-level VC implementation with provable deadlock freedom; 4 independent TSV ports must be physically routed.
4. 3D-ICE model based on actual per-block floorplan, TIM, HBM placement, cooler geometry, coolant flow.
5. Power-calibrated 120W sustained / 170W preventive / 180W peak INCLUDING HBM if on package.

## Package power guard including added HBM watts
Existing protective-controller model, unchanged voltage/frequency sensitivity coefficients; extra HBM+interfaces assumed +14W vs the earlier example. Raw extreme demand **199.509W** (hypothetical) before DVFS. Observed proxy:

| Simulated time | Applied power | State | P clock-scale | E clock-scale | GPU clock-scale |
|---|---:|---|---:|---:|---:|
| 0.001s | 176.0W | GUARD | 1.0000 | 0.7292 | 1.0000 |
| 2.000s | 176.0W | GUARD | 1.0000 | 0.7292 | 1.0000 |
| 5.000s | 120.0W | SUSTAINED | 0.9068 | 0.3000 | 0.3500 |

**Remaining blocker:** even with no DDR saturation, the illustrative 120W sustained limit imposes major CPU/GPU frequency reductions for this power demand, potentially undermining sustained 8K rendering. This power controller is a mathematical abstraction using uncalibrated V/F/P curves, not fast hardware RTL/VRM validation. The separate lumped thermal RC study is not power-coupled into this controller.
