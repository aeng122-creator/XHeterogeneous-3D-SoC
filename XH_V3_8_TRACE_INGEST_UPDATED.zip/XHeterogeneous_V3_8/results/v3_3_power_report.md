# V3.3 — 170 W preventive / 180 W boost protection test

**Scope:** Separate, 1 ms per-step Python power-and-two-tier-thermal surrogate with synthetic CPU/GPU/NPU watt demands. This does not validate silicon power/thermal safety or actual frequency-perf behavior.

| Scenario | Input demand (W) | Max applied (W) | 8 s / run avg (W) | Final mode | Tier1 / Tier2 C |
|---|---:|---:|---:|---|---|
| idle | 10.60 | 10.60 | 10.60 | BOOST | 28.6 / 28.4 |
| moderate | 172.31 | 171.15 | 135.00 | SUSTAINED | 66.1 / 67.9 |
| extreme | 245.51 | 176.00 | 135.00 | SUSTAINED | 71.9 / 62.4 |
| extreme_hot_ambient | 245.51 | 176.00 | 135.00 | SUSTAINED | 81.9 / 72.4 |
| sensor_failure | 245.51 | 176.00 | 125.33 | SAFE | 56.6 / 59.1 |

- Request 172.31 W: preventative control starts above 170 W; maximum applied is 171.15 W in the modeled controller.
- Request 245.51 W: initial 176 W capped boost; drops to 120 W once the finite 120 J boost credit is exhausted (approximately 2.14 seconds in this scenario).
- Sensor fault at t=1 s: from that time the applied power is capped to 100 W and the fault is latched until explicit reset; the table peak is the pre-fault boost power.
- The 8-second mean of 135 W under a boost profile is consistent with 120 W sustained plus a single 120 J initial boost allowance (120 + 120/8 = 135 W); it is **not** a constant 135 W operating envelope.
- The temperatures are derived from a toy two-node RC and **are not realistic chip hotspot predictions**.
- The 170 W guard is a software *model behavior*. In real hardware, an independent fast power clamp must handle transients; sensor/rail dynamics, VRM, thermal gradients, sensor failure recovery, and ISA/GPU performance feedback are not simulated.

## Reproduce

```bash
python -m sim.run_power_protection --out results/v3_3_power_protection.json
python -m unittest discover -s tests -v
```
