# V3.8 Trace Ingestion Patch — October 31, 2026

## Implementation

File updated: `sim/v38_trace_ingest.py`.

- Preserves existing `Access`, `iter_pin`, `iter_csv`, `BoundedHBMLRU` and CLI behavior for backward compatibility.
- Adds `TraceIngestionEngine` with methods `ingest_cpu_pinatrace`, `ingest_gpu_hbm_trace` and `ingest_hbm_address_trace`.
- CPU Pin raw memory operands are measured as **RAW bounded operand-line reuse**. The engine explicitly does not label this as HBM hit rate or count compression events based only on address repetition.
- Normalized `HBM_IN` traces drive a finite-capacity 64-byte cache line LRU model. Reported hit rates are modelled, not hardware measured. Multi-line accesses are split, writeback and eviction are accounted in the simple write-allocate policy.
- GPU `cycle,bytes` traces use decimal GB/s with the supplied clock (2.5 GHz by default) and observation window equal to last minus first cycle plus 1; sparse cycles count as zero-demand cycles. Bytes measure **offered load, not achieved throughput**.
- GPU address-only HBM_IN event streams allow modelled cache residency but **no GB/s without real timestamps**.
- Input files are parsed incrementally. Faulty formats or unordered/negative GPU samples are rejected.
- No external traces were found in the project. All bundled trace samples carry `EXAMPLE_SYNTHETIC` in their names.

## Reproducible demo (NOT real application benchmark)

Run:

```
python -m sim.v38_trace_ingest --cpu-trace EXAMPLE_SYNTHETIC_pinatrace.txt --gpu-trace EXAMPLE_SYNTHETIC_GPU_CYCLES.csv --hbm-input EXAMPLE_SYNTHETIC_hbm_in.csv --capacity-lines 4 --output results/V3_8_TRACE_DEMO.json
python -m unittest discover -s tests -q
```

Example outcome:

| Metric | Synthetic output | Meaning |
|---|---:|---|
| Pin raw operand events | 3 | Raw process-virtual operand events only |
| Pin bounded line reuse | 33.33% | Not HBM hit rate |
| Normalized HBM input | 8 line requests | Test dataset |
| HBM LRU hits | 4/8 = 50% | Modelled for 4 cache lines |
| GPU sampled demand | 453.33 GB/s | With assumed clock 2.5 GHz; not achieved bandwidth |

The example demand exceeds the default **assumed** memory budget of 204.79 GB/s; this is not a NoC saturation measurement.

## Verification / Sign-off limits

A real HBM hit estimate requires traces **at the HBM entrance after L1/L2/L3**, with correct physical addresses, CPU/GPU address mapping and coherent write semantics. To measure overall program performance, record injection timing, flow control, service/completion and working-set behavior. Actual 3D TSV/NoC deadlock safety, PDK power, thermal hotspots and real 8K GPU performance remain unresolved.
