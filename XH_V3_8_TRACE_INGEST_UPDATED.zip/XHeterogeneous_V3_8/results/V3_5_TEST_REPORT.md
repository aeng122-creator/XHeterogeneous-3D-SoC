# X-Heterogeneous 3D SoC V3.5 — reproducible synthetic test report

> Scope: cycle-stepped external-memory and NoC proxy only. **Not** actual measured CPU/GPU/DRAM performance or gem5/GPGPU-Sim.

## Configuration
- Baseline: Quad DDR5-6400, 4×64-bit, 204.8 GB/s theoretical peak, **153.6 GB/s assumed sustained**.
- Candidate: LPDDR5X-8533, custom 8×32-bit (256-bit), 273.056 GB/s peak, **204.792 GB/s assumed sustained**.
- 50% GPU line compressibility, compressed line at 32B vs 64B; this yields ~25% GPU bytes saved, NOT 25% total DRAM bytes.
- 28 routers Clustered Fat-Link Mesh and 4/8 distributed PHY endpoints (same router count).
- Common CPU/GPU/NPU synthetic input rates, measured at L3-miss traffic injector, not a real renderer. 5,000 cycles offered load.
- Preservation of 120 W sustained, 170 W guard and 180 W boost power constraints.

## Memory timing and backlog
| Scenario | Memory | Physical demand GB/s | GPU P95 cycles | Drain after injection cycles | Mean pending |
|---|---|---:|---:|---:|---:|
| mixed | ddr5_quad | 204.640 | 1752 | 1691 | 801.27 |
| mixed | lpddr5x_no_compression | 204.640 | 188 | 79 | 51.2 |
| mixed | lpddr5x_compression | 164.880 | 117 | 37 | 15.33 |
| heavy_130pct | ddr5_quad | 266.048 | 3663 | 3693 | 1755.81 |
| heavy_130pct | lpddr5x_no_compression | 266.048 | 1601 | 1553 | 961.45 |
| heavy_130pct | lpddr5x_compression | 214.144 | 408 | 300 | 227.72 |
| extreme_160pct | ddr5_quad | 327.520 | 5585 | 5706 | 2710.61 |
| extreme_160pct | lpddr5x_no_compression | 327.520 | 3024 | 3048 | 1914.75 |
| extreme_160pct | lpddr5x_compression | 263.616 | 1624 | 1488 | 1231.71 |
| uncompressible_100pct | ddr5_quad | 204.640 | 1752 | 1691 | 801.27 |
| uncompressible_100pct | lpddr5x_no_compression | 204.640 | 188 | 79 | 51.2 |
| uncompressible_100pct | lpddr5x_compression | 204.640 | 188 | 79 | 51.2 |

### Matched full NoC + L3 timing (same trace and same 28-router network)
| Memory | GPU P95 cycles | CPU-P P95 cycles | CPU-E P95 cycles | Total NoC energy/request nJ | L3 miss ratio | Transferred MB |
|---|---:|---:|---:|---:|---:|---:|
| Quad DDR5 + separated cache | 1534 | 2230 | 4046 | 2.947 | 0.9804 | 0.3231 |
| LPDDR5X + compression + shareable L3 | 451 | 1215 | 2492 | 2.353 | 0.9699 | 0.2970 |

IMPORTANT: The performance comparison includes distributed memory endpoints in **both** cases. Without distributing ports, the faster LPDDR replies can create a new central Mesh bottleneck; this is why the endpoint design is part of V3.5. All measurements are synthetic model output.

## Power protection sensitivity
| Additional controller/PHY power assumption | Raw requested package W | Boost peak limited W | End of 5 s W | Mode |
|---|---:|---:|---:|---|
| additional_uncore_0W | 185.509 | 176.0 | 120.0 | SUSTAINED |
| additional_uncore_4W | 189.509 | 176.0 | 120.0 | SUSTAINED |
| additional_uncore_8W | 193.509 | 176.0 | 120.0 | SUSTAINED |

No LPDDR PHY power, DRAM-die power, or compression-engine power has been extracted from silicon. A protective clamp in this proxy does NOT demonstrate sustained CPU/GPU performance or prove real-world electrical/thermal safety.

## Verdict
1. **Mixed input**: LPDDR + synthetic GPU compression lowers the offered physical traffic below the assumed sustained memory limit, and queue delays drop sharply.
2. **Heavy at 130% and 160%**: LPDDR + compression still exceeds 204.792 GB/s and remains congested. No absolute claim of bottleneck elimination is valid.
3. **Incompressible GPU traffic**: compression offers no savings; LPDDR alone reduces, but does not completely prevent, queue saturation near peak.
4. **NoC and thermal**: distributed PHYs improve NoC locality in the model, but actual place-and-route, power and temperature must be validated.
5. **Intel Arc 140V reference only**: not a GPU cycle simulator and not real 8K rendering.

## Reproduce
```bash
python -m unittest discover -s tests -v
python -m sim.run_v35_study --out results/v3_5_study.json
```
