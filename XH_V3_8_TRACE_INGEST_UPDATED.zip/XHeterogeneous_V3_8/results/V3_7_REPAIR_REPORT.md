# X-Heterogeneous V3.7 — Repair & Verification Report

**Status: REPAIRED SOFTWARE PROXY; NOT SILICON-VALIDATED / NOT TAPEOUT READY.**

## What changed

1. Replaced duplicate-address frequency as HBM hit estimator with a **bounded 64-byte-line LRU tag cache**. Hits occur only for resident lines; eviction and DDR read/dirty writeback traffic are tracked. No forced 15%–85% clamp. Can ingest external memory-reference CSV (`cycle,agent,address,operation,value`). Example included workloads are **synthetic**, not real Blender/Intel traces.
2. Added a *functional serialized coherence directory proxy*: GPU and CPU can read each other's writes; a new writer invalidates existing sharers; ownership downgrades and dirty-line DDR writebacks are visible. **NOT** a timing-accurate MESI/CHI implementation: private L1/L2 cache states, hazards, ordering/fences, and concurrent races are not modeled.
3. Added a finite-buffer **cycle-indexed distributed TSV gateway model**, backpressure, adaptive escape to alternate peripheral gateways using deterministic XY paths. One-directional fallback paths are checked for local loops. **4 TSV cycles remains an explicit input assumption**, NOT a measured physical timing. No flit-level VC allocation/credits or formal deadlock proof exists.
4. Added **120W/170W/180W** power management with explicit per-domain P/E/GPU/NPU controllable demand, fixed HBM/NoC/cache/IO power, 176W preventive target, a finite boost-energy credit, duty-cycle throttling if minimum DVFS is not enough, and **infeasible** flag when fixed power alone exceeds the applicable cap. No false claim of safe 1.5GHz at 470W.
5. Actually integrated versioned `config/thermal_rc.json` into a multi-node RC solver: lower CPU tier, upper GPU/L3 tier, side HBM stack and stepped copper plate, coolant. Power delivered to thermal nodes is conserved within solver precision. **Lumped averages, not local hotspots; RC constants are illustrative and not PDK/CFD calibrated**.
6. Added backward-compatible methods `calculate_dynamic_hbm_hit_rate`, `simulate_interconnect_tier`, `enforce_120w_thermal_limit` for the original user example; their outputs are corrected and labelled as model results.

## Reproducible runs

- `python -m unittest discover -s tests -v`: **76 tests passed** (51 legacy + 25 new) on the current runtime.
- `python -m sim.run_v37_study --out results/v3_7_study.json` generates below.

### Synthetic HBM reference traces

Example HBM capacity **256 lines ×64 bytes = 16KiB**, deliberately scaled for eviction testing. 64-line comparator = 4KiB. Neither is the proposed physical 16GB HBM3 capacity.

| Trace (6000 requests) | HBM hit rate at 256 lines | HBM hit rate at 64 lines |
|---|---:|---:|
| Streaming, unique addresses | 0.00% | 0.00% |
| Reuse of 96 lines | 98.40% | 0.00% |
| Mixed 75% hot / 25% streaming | 72.77% | 34.05% |

These outcomes emerge from **cache occupancy/replacement**, not user-injected hit probabilities. They establish code correctness, **not real-world HBM hit rate**. An actual workload must provide traced memory-reference addresses, and physical capacity mapping must be represented.

### Vertical gateway congestion test

600 cross-tier request packets over 150 injection cycles; model packet/gateway service is 1 packet per cycle with 4-cycle assumed TSV crossing plus horizontal XY hops:

| Design | P95 service+route latency | P99 latency | Escape packets |
|---|---:|---:|---:|
| 1 TSV gateway | 432 cycles | 450 cycles | 0 |
| 4 distributed gateways | 13 cycles | 13 cycles | 442 |

This is a deliberately congested gateway queue **proxy**, not RTL cycle-accurate Garnet/TSV; it does not prove deadlock freedom or guarantee these reductions on a real die.

### Power and RC thermal response

Synthetic demand: **199.51W** total at nominal activity, including **14W assumed HBM** on-package. PL1=120W, PL2=180W, pre-emptive target=176W above 170W, finite 120J boost credit.

| Time | Applied model power | CPU tier average | GPU/L3 tier average | HBM average |
|---|---:|---:|---:|---:|
| 0.1 s | 176W | 30.69°C | 30.53°C | 30.16°C |
| 2.0 s | 176W | 40.27°C | 37.75°C | 32.62°C |
| 2.5 s | 120W | 41.13°C | 38.66°C | 33.25°C |
| 20 s | 120W | 51.70°C | 49.07°C | 44.42°C |
| 120 s | 120W | 53.73°C | 50.96°C | 46.48°C |

**These are arbitrary-assumption RC node averages and do not validate cooling or thermal margins.** In the 120W-only legacy example (`35W static + 12.5 intensity`), power caps at 120W by reducing model DVFS to 35% and duty fraction to 70.7%, rather than reporting the previous invalid 470.94W "stabilized".

## Unresolved engineering gates

- Add actual CPU/GPU memory traces and benchmark suites before claiming HBM Hit Rate for real workloads.
- Implement timing-accurate cache-coherence protocol with race/interleaving and store ordering tests.
- Implement 2D mesh routers and flit-level escape VC with credit allocation, plus formal channel-dependency/deadlock verification and physically extracted TSV timing.
- Obtain floorplan/PDK and per-block activity/power for calibrated power and hotspot thermal analysis (e.g., gem5, GPGPU-Sim/Accel-Sim, and a thermal solver/3D-ICE-compatible stack mapping).
- Validate LPDDR5X/DDR5/HBM electrical/timing and package power scope; external DDR power, pump, fans remain out of package budget.

**Do not use the present software results as proof of 8K rendering performance or manufacturability.**
