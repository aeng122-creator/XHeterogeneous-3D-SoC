# X-Heterogeneous V3.8 — verification bridge results

## Executed in this session

- Built on V3.7 source, preserving all previous scripts, configs and reports.
- Ran Python `unittest discover`: **91 tests passed**, including previous tests plus 15 new V3.8 tests.
- Read a **synthetic** sample CSV with eight already-normalized HBM boundary requests: 4 hits, 4 misses, 50% hit rate, 4 resident lines, 256 bytes DDR reads in a four-line HBM LRU proxy. This is NOT a real workload trace or HBM3 hit rate measurement.
- Checked all pairs of XY paths on **4x7 2D mesh**: **28 routers, 90 directed channels, 2016 observed dependency-edge occurrences**, and an **acyclic escape channel dependency graph**. The result is limited to X-before-Y escape routing without adaptive/escape re-entry and DOES NOT establish deadlock freedom across TSV, virtual networks, coherence responses, etc.
- Ran a synthetic **read-only** trace (8 expanded line requests) through the retained Python network/memory proxy: 8 completed / 0 unfinished. This is not gem5 and the trace order is not a physical instruction/cycle timestamp.
- Ran foundry calibration gate: `CALIBRATION_BLOCKED`; the V3.8 package does not contain licensed N3 or Intel 18A PDK or timing/power macro libraries.

## Important technical corrections to the proposed roadmap

1. **Intel Pin** instruments CPU memory operands (normally virtual addresses and program order); they are not memory requests after L3 misses and do not provide reliable cycle timestamps without extra instrumentation. Real GPU memory addresses must be normalized to an identical physical address space before CPU-GPU coherence comparison. Traces and workloads must include provenance and workload phase.
2. In **gem5 Garnet 2.0**, `vcs_per_vnet=4` means four VCs *per virtual network*, not one global 'fourth escape VC'. Proper escape VC reservation, routing and message-class dependencies require custom implementation and verification. The supplied `topology/D_mesh_graph.json` is a graph description, not an executable gem5 topology.
3. **BookSim 2.0 traffic testing** is necessary for performance assessment but cannot prove deadlock-freedom for all reachable configurations. The V3.8 check is limited to the XY escape channel-dependency graph and is neither a full proof nor an RTL implementation.
4. **McPAT/CACTI** can guide architectural exploration, but do not yield foundry-calibrated watt measurements for proprietary TSMC N3 or Intel 18A by specifying `V=0.8` or a node name. The PDK/license, voltage-frequency curves, macro models, activity traces and material stack are blocking dependencies.
5. **3D-ICE** requires stack and floorplan/power inputs derived from physical geometry and material properties. The existing `thermal_rc.json` consists of illustrative lumped assumptions and must not be presented as actual cooler performance.

## Official and academic references

- gem5 Ruby protocols: https://www.gem5.org/documentation/general_docs/ruby/
- gem5 Garnet 2.0: https://www.gem5.org/documentation/general_docs/ruby/garnet-2/
- Intel Pin: https://www.intel.com/content/www/us/en/developer/articles/tool/pin-a-binary-instrumentation-tool-downloads.html
- BookSim 2.0: https://github.com/booksim/booksim2
- McPAT research: https://ieeexplore.ieee.org/document/5375438
- CACTI: https://github.com/HewlettPackard/cacti
- 3D-ICE: https://www.epfl.ch/labs/esl/research/open-source-tools-datasets/3d-ice/

## External validation gates (not completed)

- [ ] Capture real CPU and GPU workloads with timestamps/order and unified address interpretation
- [ ] Run trace-driven full L1/L2/L3 filtering before HBM cache hit/miss measurement
- [ ] Run gem5/Garnet coherence and routing with verified custom VCs and link widths
- [ ] Run BookSim 2.0 uniform, tornado, hotspot and adversarial saturation sweeps
- [ ] Prove full adaptive + escape + TSV + coherence dependency freedom
- [ ] Obtain licensed process/standard cell/SRAM macro models, calibrate power
- [ ] Convert measured power maps and actual geometry into 3D-ICE, confirm PL1 120W / PL2 180W and all hotspots
