# V3.8 External Trace Formats

The three included `EXAMPLE_SYNTHETIC_*` datasets are **examples only**, not captures from Intel Pin, gem5, games, rendering applications or a GPU profiler.

## 1. Pin raw CPU memory operands (no HBM hit claim)

```
R 0x1000 8
W 0x2000 4
R 0x1000 8
```

The input is a process virtual address stream. It **does not** reveal LLC or HBM hits. The tool calculates only a bounded reuse proxy; it neither invents an HBM hit percentage nor a number of cache compressions.

## 2. Address stream at the **HBM_IN boundary**

```csv
order,agent,address,op,boundary,size
0,P,0x1000,R,HBM_IN,8
1,GPU,0x2000,R,HBM_IN,64
2,P,0x1000,R,HBM_IN,8
```

`agent` = `P`, `E`, `GPU` or `NPU`; `op` = `R`/`W`; `address` is a byte address. Real multi-agent replay requires a consistent **physical address domain** (or correct mapping), and events filtered through L1, L2, L3. `order` records event order, **not cycles**. HBM hit rate is the output of a finite-capacity, LRU **model** only. To model actual HBM capacity, set `--capacity-lines` to the appropriate number; the CLI default of 64 is an intentionally tiny test configuration.

## 3. GPU traffic demand with timestamps

```csv
cycle,bytes
0,64
1,128
3,256
```

`cycle` is an *observed/recorded* cycle index, `bytes` is demanded in that cycle. Multiple rows with the same cycle are added. Skipped cycles count as zero-demand cycles. The cycle clock must be supplied with `--clock-ghz` if not 2.5 GHz. GB/s is calculated with **decimal GB**; do not divide by 1024 a second time. This form contains no addresses, so it **cannot** calculate HBM hit rates.

## Examples (from project root)

```bash
python -m sim.v38_trace_ingest --cpu-trace EXAMPLE_SYNTHETIC_pinatrace.txt --gpu-trace EXAMPLE_SYNTHETIC_GPU_CYCLES.csv --hbm-input EXAMPLE_SYNTHETIC_hbm_in.csv --capacity-lines 4 --output results/V3_8_TRACE_DEMO.json
python -m sim.v38_trace_ingest traces/EXAMPLE_SYNTHETIC_hbm_in.csv --capacity-lines 4
python -m sim.v38_trace_ingest traces/EXAMPLE_SYNTHETIC_pinatrace.txt --format pin
```

To use a real capture, replace the filenames with your own traces and document **source application, timing frequency, address space and level of memory hierarchy where captured**. An unfiltered Pin log is never a substitute for LLC/HBM input traces.

## Limits

This tool does not run Intel Pin, GPGPU-Sim, gem5, a shader, or a physical HBM model. It does not simulate NoC network service time, MESI coherence, leakage, actual power or heat. A memory demand higher than an assumed DDR/LPDDR service cap shows possible pressure but does not prove the NoC itself saturated.
