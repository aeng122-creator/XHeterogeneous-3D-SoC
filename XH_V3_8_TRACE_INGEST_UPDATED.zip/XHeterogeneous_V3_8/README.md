# X-Heterogeneous 3D SoC V3.7 — Corrected Functional and Power/Thermal Proxy

This is the **updated V3.6 project, preserving its previous source, simulations, and tests**, with the repair module `sim/v37_advanced_power_core.py`, reproducible study script, config and additional unit tests. The corrected model **does not** establish real-chip manufacturability, measured energy or temperature, actual IPC/GPU throughput, or deadlock-free RTL.

## Key corrections

- HBM Hit Rate is computed from **resident 64-byte cache lines** with finite capacity, LRU, eviction, DDR read/miss and dirty-line writeback. No artificial 15% minimum hit rate.
- Serialized CPU/GPU directory functional checks of ownership and write visibility (not MESI/CHI timing verification).
- Bounded TSV gateway queues with assumed four-cycle vertical latency, horizontal XY detour and escape channel selection (not a full flit-level router/deadlock proof).
- Stronger power protection: **120W sustained, preventive reduction from 170W, 176W guard target, 180W absolute Boost model**, finite 120J burst energy; duty-cycle stall or explicit infeasibility when lowering clocks cannot satisfy the cap.
- Reads `config/thermal_rc.json` and evolves two silicon tiers + adjacent HBM stack + stepped copper cooler using a lumped RC ODE. Temperatures are assumed averages, not validated hotspots.

## Run on Windows

Extract the ZIP, enter the `XHeterogeneous_V3_7` folder, and double-click **`RUN_V37_WINDOWS.bat`** with Python 3.10+ installed. This runs all regression tests and the V3.7 study.

## Run on Linux/macOS

```bash
cd XHeterogeneous_V3_7
bash RUN_V37.sh
```

Manual commands:

```bash
python -m unittest discover -s tests -v
python -m sim.run_v37_study --out results/v3_7_study.json
```

To test an **externally supplied real address trace**:

```bash
python -m sim.run_v37_study --trace path/to/trace.csv --out results/external_trace.json
```

CSV columns: `cycle,agent,address,operation,value`, e.g. `0,P,0x1000,R,0` and `1,GPU,0x1000,W,42`. Agent = P/E/GPU/NPU, operation R/W, address is a byte address. The value field is a simplified token per cache line for functional verification, **not byte-accurate memory or an actual CPU trace format**. The example code includes synthetic patterns and accepts actual traces only if supplied externally.

## Files to inspect

- `sim/v37_advanced_power_core.py`: corrected HBM, directory, TSV, power/thermal logic and compatibility methods with the user's sample.
- `sim/run_v37_study.py`: scenario generation; never claims synthetic requests are true CPU/GPU traces.
- `tests/test_v37.py`: 25 added tests plus previous 51 tests.
- `results/V3_7_REPAIR_REPORT.md`: methods, numbers, gaps and limitations.
- `results/v3_7_study.json`: regenerated machine-readable output.
- `config/v37_assumptions.json` and `config/thermal_rc.json`: assumed design parameters, not calibrated silicon characteristics.

## Revision scope

The original V3.6 functional simulation files are kept unchanged for historical comparison. **V3.7 fixes are active when running `sim.run_v37_study` and the backward-compatible V3.7 core**, not when invoking the old V3.6 study by itself.

**Status: SOFTWARE-VERIFIED PROTOTYPE ONLY — not a measured silicon design, not a real gem5/GPGPU-Sim joint simulation and not tapeout-ready.**

---

# V3.8: trace-driven verification bridge (added October 2026)

This version **does not claim final sign-off**. It retains V3.7 and adds streamed trace parsing, a bounded HBM line-cache replay, limited escape-only routing dependency checking, a read-only legacy NoC adapter and a strict foundry calibration gate. See `integration/V3_8_SIGNOFF_BRIDGE.md` for limitations and acceptance criteria.

Run from the project root with Python 3.10+:

```bash
python -m unittest discover -s tests -q
python -m sim.v38_trace_ingest traces/EXAMPLE_SYNTHETIC_hbm_in.csv --capacity-lines 4 --output results/v38_example_hbm.json
python -m sim.v38_escape_checker --rows 4 --cols 7
python -m sim.v38_calibration_gate config/v38_foundry_calibration_template.json
python -m sim.v38_model_trace_adapter traces/EXAMPLE_SYNTHETIC_READ_ONLY.csv --output results/v38_example_network.json
```

**Important:** `RAW` memory references from Intel Pin are CPU process virtual addresses, NOT LLC misses; don't report their repeated-address ratio as a measured HBM Hit Rate. The default included traces are explicitly synthetic examples. Preserve process/thread/ASID and address translation before merging CPU/GPU references.

---

## Updated trace ingestion (October 31, 2026)

`sim/v38_trace_ingest.py` now provides `TraceIngestionEngine` with `ingest_cpu_pinatrace()`, `ingest_gpu_hbm_trace()` and `ingest_hbm_address_trace()`, while retaining the existing V3.8 low-level parser/cache APIs. It streams external files instead of fabricating traffic. See `traces/TRACE_FORMATS.md` for strict format and provenance requirements.

```bash
python -m unittest discover -s tests -q
python -m sim.v38_trace_ingest --cpu-trace EXAMPLE_SYNTHETIC_pinatrace.txt --gpu-trace EXAMPLE_SYNTHETIC_GPU_CYCLES.csv --hbm-input EXAMPLE_SYNTHETIC_hbm_in.csv --capacity-lines 4 --output results/V3_8_TRACE_DEMO.json
```

**The supplied project only includes synthetic sample traces at present.** Pin operand reuse is reported as RAW reuse, **not as HBM hit rate**; GPU cycle/bytes data measures *offered traffic demand*, **not NoC throughput**. A valid HBM hit estimate requires a modeled bounded cache fed with a correctly captured HBM_IN stream. Running this importer is not a replacement for gem5, BookSim or foundry-calibrated simulation.
