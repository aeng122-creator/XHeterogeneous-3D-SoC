@echo off
cd /d "%~dp0"
python -m unittest discover -s tests -v
if errorlevel 1 (
  echo Unit tests failed.
  pause
  exit /b 1
)
python -m sim.run_v37_study --out results\v3_7_study.json
pause
