#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m unittest discover -s tests -v
python3 -m sim.run_v36_study --cycles 12000 --out results/v3_6_study.json
