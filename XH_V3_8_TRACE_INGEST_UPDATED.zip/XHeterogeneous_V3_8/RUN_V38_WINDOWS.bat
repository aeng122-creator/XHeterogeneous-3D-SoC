@echo off
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python not found. Install Python 3.10 or later.
  pause
  exit /b 1
)
python -m unittest discover -s tests -v
if errorlevel 1 (
  echo Tests FAILED
  pause
  exit /b 1
)
echo ----- HBM SAMPLE (SYNTHETIC) -----
python -m sim.v38_trace_ingest traces\EXAMPLE_SYNTHETIC_hbm_in.csv --capacity-lines 4
 echo ----- ESCAPE-ONLY XY DEPENDENCY CHECK -----
python -m sim.v38_escape_checker --rows 4 --cols 7
 echo ----- FOUNDRY CALIBRATION GATE -----
python -m sim.v38_calibration_gate config\v38_foundry_calibration_template.json
pause
