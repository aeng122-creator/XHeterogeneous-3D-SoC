# V3.6 — Why these exports are not directly runnable in gem5 / 3D-ICE

Status: research prototype. No Intel/TSMC PDK, silicon floorplan, physical TSV count, DRAM controller RTL, or real die materials have been provided. The files are inputs to **porting and calibration**, not simulator-native, validated files.

## Hierarchy
- Lower physical silicon tier: 8 P cores + 32 E cores, 3MiB distributed L1, 48MiB L2.
- Upper physical silicon tier: Arc Xe2-class GPU, NPU, 112MiB distributed L3 (96MiB CPU, 16MiB GPU).
- On-interposer **separate HBM3 die stack** with a 1024-bit I/O is not a third tier on the CPU pyramid. It acts as a memory-side cache, called "L4" here to avoid confusion with SRAM L3. DDR5 Quad is backing main memory.
- GPU and its 16MiB L3 are on the **same** upper tier. Their preferred path is **local/on-tier**, not a TSV. Dedicated TSVs serve transfers between tiers. Directory/synchronization/coherence for CPU/GPU buffers still requires verification.

## Memory
- HBM3 6.4Gb/s/pin × 1024 bits = 819.2 GB/s peak; at **assumed** 70% effective = 573.44 GB/s. Quad DDR5-6400 peak 204.8 GB/s; at 75% = 153.6 GB/s. **Do not sum** cache and backing DDR bandwidth as if both served the same line concurrently.
- At a 263.62 GB/s **uncompressed** demand, DDR utilization <=85% requires HBM hits >=50.5%. With adaptive compression synthetic physical demand 236.51GB/s, the threshold becomes ≈44.8% (assuming miss mix unchanged).
- Controlled hit percentages in `run_v36_study.py` are stimulus inputs, **not measured hit ratios from workloads**. To predict hit ratios: feed address traces through actual 16-24GB HBM tag/way/replacement model and realistic compression.
- `v36_prototype.py` models byte-credit queues with simplified fixed latency; it has no HBM banks, refresh, or JEDEC timings.

## Isolation and coherence
- `IsolatedL3` uses separated CPU/GPU capacity namespaces. It does not implement a directory protocol, cache-line permissions, ECC metadata or dirty eviction. The `Fully Shared CPU` pool still must be non-inclusive across CPU L2/L3 and memory consistent with GPU buffers.
- Migrate to Ruby/Garnet to prototype directory coherence, TLB/IOMMU, ATS, synchronization, and read/write ordering.

## Escape VC
- Prototype chooses congestion-aware peripheral paths and specifies **deterministic XY escape VC** fallback. Keep escape packets on that VC until destination: do not route them back into an adaptive VC.
- Real router requires reserved credits/buffers and formal channel-dependency analysis for deadlock freedom. `EscapeRoutingPolicy` itself is not a flit-level VC implementation.
- In Garnet/HeteroGarnet: implement a custom RoutingUnit, VC allocation/flow-control, and a topology with explicit upper/lower gateway endpoints.

## Thermal RC export
- `config/thermal_rc.json` is a **lumped 4-node** model. R in K/W, C in J/K. Model: CPU tier ↔ stepped copper plate ↔ coolant, GPU tier ↔ plate ↔ coolant, adjacent HBM ↔ plate ↔ coolant, CPU ↔ GPU.
- It is consumed by `ThermalRC` in this package, but **3D-ICE cannot read this JSON directly**. Convert into a 3D-ICE `Stack Description File` and `.flp` with valid geometry/materials. Physical data needed: dimensions, height, TIM, TSV density, anisotropic conductivity, coolant inlet temp and flow, local heat-source floorplans, interposer and HBM heat path.
- Benchmark the 2-second 180W boost followed by 120W sustained, **including on-package HBM watts**. The hypothetical constant-180W-for-120s case is a stress sensitivity and violates the boost-duration policy.

## Power
- Keep 170W preventive, 180W absolute boost, 120W sustained. HBM on package draws additional watts and must consume this same budget. DDR5 on motherboard is outside package limit.
- The old hypothetical extreme demand 185.51W + 12W HBM + 2W controllers = 199.51W before DVFS. That is not a silicon-measured power demand. Capping to 180W necessarily throttles if this premise holds.

References:
- Samsung HBM3 datasheet summary: https://semiconductor.samsung.com/dram/hbm/hbm3/
- Intel Xeon Max HBM caching mode: https://www.intel.com/content/www/us/en/docs/vtune-profiler/cookbook/2023-2/profiling-hbm-performance-on-intel-max.html
- gem5 Garnet routing/VCs: https://www.gem5.org/documentation/general_docs/ruby/garnet-2/
- 3D-ICE 4.0 thermal modeling: https://www.epfl.ch/labs/esl/research/open-source-tools-datasets/3d-ice/
