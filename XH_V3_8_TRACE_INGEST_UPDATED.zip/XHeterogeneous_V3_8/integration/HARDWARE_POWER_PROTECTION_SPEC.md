# X-Heterogeneous V3.3 — hardware safety design requirements (proposed, not fabricated)

## Power policy

- PL1: **120 W sustained package target** (precise averaging and time window require system validation).
- Guard begins: **170 W** package demand. A predictor/DVFS controller begins throttling, and aims at <=176 W while a boost-energy budget is available.
- PL2: **180 W maximum boost package target**, not an unlimited operating point. Use independent, fast hardware current and power limiters; firmware must not be the sole over-power protection.
- Boost budget in the software model: **120 J excess energy credit**, so maximum 180 W can be supported for 2 s initially if other conditions permit. 176 W can be maintained for 120/(176-120)=2.14 s. This is an *illustrative* power-envelope design, not an automotive/VRM-grade peak limit specification.

## Sensing and immediate reaction

- On-die digital thermal sensors: near each P-core hotspot, E-cluster hotspots, the GPU SM hotspot regions, the NPU and L3; minimum independent measurements for top and bottom tiers. Add local analog over-temperature protection independent of normal management firmware.
- VRM/PMIC telemetries: package input voltage/current and rail-specific P/E/GPU/NPU power estimates, with per-rail instantaneous current and under-voltage limiters.
- A dedicated hardware power-limit/thermal-fault path must operate independently of instruction execution, OS scheduling and firmware; bounded reaction time must be **specified and measured** during RTL/AMS/PDN signoff. The Python prototype models this as zero-delay and thus cannot verify physical reaction time or transients.
- Package control: dynamic voltage/frequency scaling for P/E/GPU/NPU plus optional clock modulation; priority-aware power allocation. For core compute under pressure, E/NPU/GPU then P are reduced in this first model, but real policy must be tuned for CPU/GPU workload throughput and starvation behavior.
- Thermal thresholds in the prototype: **85°C warning, 95°C strong throttle, 105°C shutdown trip**. All three are provisional assumptions; safe values require process/Jmax characterization, local hotspot measurement and FEA/CFD of stepped water-cooled two-tier package.
- Fault sensor invalid, stale for >10 ms, or a mismatch across sensors: disable boost and apply **100 W** fail-safe model cap; latch the fault until explicit reset after verified valid sensors and acceptable temperatures. Real failure detection should be redundant and conservative, not trust a single invalid sensor.
- If requested power cannot be limited within safe domains' feasible frequency/voltage range: enter a latched shutdown/trip. Ensure real VRM shutoff response, thermal diode calibration and system recovery state machine.

## Power-accounting scope

The 180 W target here is *package* power. External quad-channel DDR5 modules, discrete GDDR memory, liquid pump/fans, and motherboard VRM conversion losses are **not** included. Whether package I/O PHY energy is inside the package limit must be specified during product definition. Clock-tree, LLC compression and off-chip memory controller are captured only by uncalibrated proxy values.

## Required validation before silicon claims

1. Per-domain voltage-frequency-power curves from standard-cell/SRAM/GPU macro libraries; energy and leakage vs. temperature and process corners.
2. IR drop, transient droop and di/dt verification with VRM models; sensor accuracy, ADC conversion delay, telemetry update time and comparator response.
3. Thermal resistance/extracted hotspot model for bottom CPU die, top GPU/NPU/L3 die, hybrid bonding and copper water block with TIM tolerances.
4. Power cap under worst-case combined CPU+GPU+NPU compute, memory-heavy load, and asymmetric hot spots, at hot ambient and min pump flow.
5. Fault insertion: failed/stale sensors, PLL failure, transient short, power rail surge, cooling loss, abrupt activity steps, router gating wake surges.
6. Throughput and fairness measurements after DVFS; the current implementation does **not** adjust CPU/GPU instruction execution latency and does not run gem5/GPGPU-Sim.

## Software verification

Run `python -m unittest discover -s tests -v` and `python -m sim.run_power_protection`. The Python controller (`sim/power_controller.py`) is a *separate time-step power-envelope surrogate*; its idealized per-step limiting must never be treated as hardware safety certification.
