# V3.8 verification bridge — NOT foundry sign-off

## What runs here

- `sim/v38_trace_ingest.py`: streamed CSV and classic Pin `pinatrace` parser. Includes a finite HBM line-LRU **HBM_IN-only** hit/miss replay; raw Pin traces cannot bypass L1/L2/L3 or address translation.
- `sim/v38_model_trace_adapter.py`: optional **read-only** trace replay into the inherited V3.7 Python network/cache proxy with explicitly synthetic injection timing. Rejects writes because the legacy network model does not implement coherence.
- `sim/v38_escape_checker.py`: constructs the channel dependency graph for every source/destination pair on a 4x7 deterministic X-then-Y **escape VC** and checks acyclicity. This is a limited *mathematical sufficient-condition check* for the escape subnetwork, not a proof for the adaptive network or the inter-layer crossings.
- `sim/v38_calibration_gate.py`: blocks foundry-level calibration claims if the process data, macro models, floorplan and workload activity are unavailable.

## External work still required

**CPU trace collection:** obtain Intel Pin Pinatrace output or DynamoRIO/Tracer-RA traces, preserve process/thread/ASID and virtual-to-physical mapping if comparing shared address spaces. Pin memory operands are virtual process addresses, **not** accurate per-cycle timing and **not** L3 misses. To estimate HBM hit rate, use an accurate lower-tier cache hierarchy to filter requests before calling the HBM cache model. Record application phase, warmup, units and trace provenance.

**GPU trace collection:** Accel-Sim or a full execution GPU simulator produces appropriate kernel/memory-level events for *compute* tasks; a graphics framebuffer/rendering workload requires a supported graphics tracing pipeline and compatible instruction model. Do not relabel compute traces as full 8K graphics workloads. Synchronize CPU/GPU clocks and use common translated addresses for coherent accesses.

**gem5 Ruby/Garnet 2.0:** `vcs_per_vnet=4` means FOUR VCs **per virtual network**, not "VC4 is escape globally". Reserve one VC per relevant vnet for deterministic XY and ensure protocol messages (requests/responses/acks) don't introduce circular inter-vnet dependencies. Choose coherence protocol deliberately (the stock MESI_Two_Level is inclusive); CPU/GPU mixed coherency requires additional controllers/protocol or an appropriate GPU protocol. A custom topology and routing source changes are needed, especially for Fat Links with differing *physical* widths; stock Garnet's flit width is network-global. Old `topology/D_mesh_graph.json` is a graph description, NOT a valid gem5 topology config.

**BookSim 2.0:** test injection rates from below saturation to well above saturation using uniform, tornado, hotspot, adversarial and request/response backpressure loads; log P50/P95/P99, goodput, fairness, stalls and draining behavior. Exhaustive formal proof requires a verified channel/buffer dependency argument; finite workloads cannot prove all possible routing states deadlock-free. Also BookSim's standard rectangular-mesh support must be verified for exact 4x7 layout or implemented as a custom topology.

**Foundry and thermal:** Foundry N3/18A proprietary PDK data are not available in this package. McPAT/CACTI are architecture-level models and **not** a sign-off PDK simulator; use licensed libraries and extraction for realistic power, leakage and area. Run 3D-ICE (or equivalent) with actual 3D floorplan, TSV placement, layer thickness, heat capacities, material properties, TIM, coolant flow and dynamic per-block power traces. Existing `config/thermal_rc.json` is uncalibrated illustrative RC only.

## Acceptance gates

| Gate | Necessary result | Current V3.8 status |
|---|---|---|
| Trace provenance | CPU/GPU *measured* address traces, timestamps and translated address space | BLOCKED: no real trace supplied |
| Memory correctness | L3-to-HBM boundary replay + HBM line hit/miss + dirty writebacks | PARTIAL: HBM line replay passes; boundary filter/real workload missing |
| Cycle-level coherence | concurrent MESI/MOESI/CHI-style races, writebacks, fences | BLOCKED: not implemented in gem5 |
| Deadlock | escape CDG proof + adaptive, TSV and protocol dependency verification | PARTIAL: 2D escape XY graph acyclic only |
| Power | licensed device/model calibration, 120W PL1 / 170W guard / 180W PL2, peak + averages | BLOCKED: no foundry calibrated device data |
| Thermal | multi-tier cooler with real power map and measured/verified materials | BLOCKED: illustrative RC only |

## Model caveats

The V3.7 project is retained for reproducibility. All legacy numerical power and render claims remain synthetic/conditional. The V3.8 trace tools deliberately reject raw traces as HBM input, and the calibration gate rejects sign-off claims without trusted process inputs. This project contains NO executable gem5, BookSim, McPAT, CACTI or 3D-ICE run or proprietary PDK.
