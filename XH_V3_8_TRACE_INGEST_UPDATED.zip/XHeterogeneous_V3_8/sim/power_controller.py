"""V3.3 research power/thermal controller (discrete-time proxy, NOT silicon RTL).

Definitions:
  170 W : preventive management starts
  180 W : hard *modeled* package power ceiling during boost
  120 W : nominal sustained envelope via a finite boost-energy credit bucket
  100 W : illustrative sensor-fault fallback

The 'hardware clamp' is an idealized zero-delay abstraction. In actual hardware,
fast current sensing, VR fault logic, frequency slew, transients and Tj calibration
must be designed and verified. No instantaneous physical safety guarantee follows.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Mapping

DOMAINS = ('P', 'E', 'GPU', 'NPU')
# Priority ordering under power pressure: light-background E first, then NPU,
# then GPU for balanced CPU/GPU workloads; P has highest protected priority.
SHED_ORDER = ('E', 'NPU', 'GPU', 'P')
FLOOR = {'P': .35, 'E': .30, 'GPU': .35, 'NPU': .30}


@dataclass(frozen=True)
class ProtectionConfig:
    sustained_w: float = 120.0
    preventive_w: float = 170.0
    boost_max_w: float = 180.0
    preventive_target_w: float = 176.0  # 4 W modeled headroom below hard clamp
    failed_sensor_w: float = 100.0
    boost_credit_j: float = 120.0       # 180 W for 2 s if initially charged
    thermal_warn_c: float = 85.0
    thermal_limit_c: float = 95.0
    thermal_trip_c: float = 105.0
    sensor_timeout_s: float = 0.01
    dt_s: float = 0.001
    ambient_c: float = 25.0
    tau_tier1_s: float = 1.8
    tau_tier2_s: float = 1.5
    # Illustrative thermal-resistance network; not CFD or package-extracted.
    r11_c_per_w: float = .62
    r22_c_per_w: float = .58
    r12_c_per_w: float = .10
    r21_c_per_w: float = .10
    # Fraction of each domain's rated power assumed to be dynamic.
    dynamic_fraction: float = .80

    def __post_init__(self):
        if not (0 < self.sustained_w < self.preventive_w < self.preventive_target_w < self.boost_max_w):
            raise ValueError('Require sustained < guard < target < boost maximum')
        if not (0 < self.failed_sensor_w <= self.sustained_w):
            raise ValueError('Sensor-fault ceiling must not exceed sustained envelope')
        if self.dt_s <= 0 or self.boost_credit_j <= 0:
            raise ValueError('Nonzero time step and boost credit required')


@dataclass
class Measurement:
    # Power demand if all requested domains operate at nominal frequency.
    requested_w: dict[str, float]
    uncore_w: float
    tier1_sensor_c: float
    tier2_sensor_c: float
    sensor_ok: bool = True
    sensor_age_s: float = 0.0


@dataclass
class State:
    clock_scale: dict[str, float] = field(default_factory=lambda: {d: 1.0 for d in DOMAINS})
    boost_credit_j: float = 120.0
    trip_latched: bool = False
    sensor_fault_latched: bool = False
    tier1_c: float = 25.0
    tier2_c: float = 25.0
    total_energy_j: float = 0.0
    time_s: float = 0.0
    preventive_events: int = 0
    clamp_events: int = 0
    sensor_fault_events: int = 0
    trip_events: int = 0
    sustained_events: int = 0


class PowerController:
    def __init__(self, cfg: ProtectionConfig = ProtectionConfig()):
        self.cfg = cfg
        self.state = State(boost_credit_j=cfg.boost_credit_j,
                           tier1_c=cfg.ambient_c, tier2_c=cfg.ambient_c)

    def _domain_power(self, maximum: float, scale: float) -> float:
        # Illustrative P~=P0[(1-alpha)+alpha*f^3]; NOT a calibrated V/F curve.
        a = self.cfg.dynamic_fraction
        return maximum * ((1-a) + a*scale**3)

    def total(self, measurement: Measurement, scale: Mapping[str, float]):
        return measurement.uncore_w + sum(self._domain_power(measurement.requested_w[d], scale[d]) for d in DOMAINS)

    def allocate(self, m: Measurement, ceiling: float) -> tuple[dict[str,float],float,bool]:
        scale={d: 1.0 for d in DOMAINS}
        raw=self.total(m,scale)
        if raw<=ceiling:
            return scale,raw,True
        # Solve by domain priority with bisection. An override of the slew limit
        # represents a hypothetical hard power limit, not firmware-only DVFS.
        for d in SHED_ORDER:
            minimum=FLOOR[d]
            at_floor=scale.copy();at_floor[d]=minimum
            if self.total(m,at_floor)>ceiling:
                scale[d]=minimum
                continue
            lo,hi=minimum,scale[d]
            for _ in range(40):
                mid=(lo+hi)/2
                temp=scale.copy();temp[d]=mid
                if self.total(m,temp)>ceiling:hi=mid
                else:lo=mid
            scale[d]=lo
            break
        actual=self.total(m,scale)
        return scale, actual, actual <= ceiling + 1e-6

    def clear_latched_faults(self, sensors_verified: bool=False, physical_reset: bool=False) -> bool:
        # Must be explicitly requested from the host after checking both sensors.
        # The software model cannot verify real sensor calibration or a VRM reset.
        s=self.state
        if not (sensors_verified and physical_reset and
                max(s.tier1_c,s.tier2_c)<self.cfg.thermal_warn_c):
            return False
        s.trip_latched=False
        s.sensor_fault_latched=False
        return True

    def step(self, demand: Mapping[str,float], uncore_w:float,
             sensor_ok=True, sensor_age_s=0.0, dt_s=None):
        c=self.cfg;s=self.state
        dt=dt_s if dt_s is not None else c.dt_s
        if dt<=0:raise ValueError('dt must be positive')
        if any(d not in demand or demand[d]<0 for d in DOMAINS) or uncore_w<0:
            raise ValueError('Domain demand must contain nonnegative P,E,GPU,NPU')
        m=Measurement(dict(demand),uncore_w,s.tier1_c,s.tier2_c,sensor_ok,sensor_age_s)
        raw=self.total(m,{d:1.0 for d in DOMAINS})
        invalid=(not sensor_ok) or (sensor_age_s>c.sensor_timeout_s)
        hot=max(m.tier1_sensor_c,m.tier2_sensor_c)
        triggered=[]
        if raw>=c.preventive_w:
            s.preventive_events+=1
            triggered.append('PREVENTIVE_170W')
        if raw>=c.boost_max_w:
            s.clamp_events+=1
            triggered.append('HARD_POWER_CLAMP')
        if invalid:
            s.sensor_fault_latched=True
            s.sensor_fault_events+=1
            triggered.append('SENSOR_FAULT_SAFE_MODE')
        elif s.sensor_fault_latched:
            triggered.append('SENSOR_FAULT_LATCHED')
        if hot>=c.thermal_trip_c and not s.trip_latched:
            s.trip_latched=True
            s.trip_events+=1
            triggered.append('THERMAL_TRIP_LATCHED')
        if s.trip_latched:
            # Fail-stop model: not a working power-gated microarchitecture.
            s.clock_scale={d:0.0 for d in DOMAINS}
            actual=0.0
            mode='TRIP'
            # Cooling continues with zero modeled *chip* dissipation.
        else:
            target=c.boost_max_w
            if raw>=c.preventive_w:
                # Begin a real (small) DVFS reduction above 170 W, instead of
                # merely logging a warning while waiting for 176 W.
                target=min(target,c.preventive_target_w,
                           c.preventive_w + .5*(raw-c.preventive_w))
            if s.boost_credit_j <= 1e-9:
                target=min(target,c.sustained_w)
                s.sustained_events+=1
                triggered.append('BOOST_BUDGET_EXHAUSTED')
            else:
                # Budget constraint for this discrete time interval, so the
                # energy bucket cannot overdraw in this step.
                target=min(target,c.sustained_w+s.boost_credit_j/dt)
            if hot>=c.thermal_limit_c:
                target=min(target,c.failed_sensor_w)
                triggered.append('THERMAL_LIMIT_95C')
            elif hot>=c.thermal_warn_c:
                # Smooth illustrative thermal derating from 176->120 W.
                thermal_cap=c.preventive_target_w - (hot-c.thermal_warn_c)*(c.preventive_target_w-c.sustained_w)/(c.thermal_limit_c-c.thermal_warn_c)
                target=min(target,thermal_cap)
                triggered.append('THERMAL_GUARD_85C')
            if invalid or s.sensor_fault_latched:target=min(target,c.failed_sensor_w)
            scale,actual,feasible=self.allocate(m,target)
            if not feasible:
                # Below minimum modeled DVFS operating points: stop simulation
                # rather than silently claiming safe power delivery.
                scale={d:0.0 for d in DOMAINS}
                actual=0.0
                s.trip_latched=True
                s.trip_events+=1
                triggered.append('POWER_LIMIT_UNREACHABLE_TRIP')
                mode='TRIP'
            else:
                s.clock_scale=scale
                mode=('SAFE' if (invalid or s.sensor_fault_latched) else 'THERMAL' if hot>=c.thermal_warn_c
                      else 'SUSTAINED' if target<=c.sustained_w+1e-6
                      else 'GUARD' if raw>=c.preventive_w else 'BOOST')
        if actual>c.boost_max_w+1e-6:
            raise AssertionError('Modeled power exceeded absolute cap')
        # Energy credits accumulate only when actual draw is below PL1.
        s.boost_credit_j=min(c.boost_credit_j,max(0.0,s.boost_credit_j+(c.sustained_w-actual)*dt))
        if s.boost_credit_j < 1e-9:
            s.boost_credit_j = 0.0
        # Thermal two-tier RC surrogate (NOT CFD, ignores power/heat density).
        if mode=='TRIP':p1=p2=0.0
        else:
            p1=sum(self._domain_power(m.requested_w[d],s.clock_scale[d]) for d in ('P','E'))+uncore_w*.30
            p2=sum(self._domain_power(m.requested_w[d],s.clock_scale[d]) for d in ('GPU','NPU'))+uncore_w*.70
        eq1=c.ambient_c+c.r11_c_per_w*p1+c.r12_c_per_w*p2
        eq2=c.ambient_c+c.r22_c_per_w*p2+c.r21_c_per_w*p1
        s.tier1_c += (eq1-s.tier1_c)*min(1.0,dt/c.tau_tier1_s)
        s.tier2_c += (eq2-s.tier2_c)*min(1.0,dt/c.tau_tier2_s)
        s.total_energy_j+=actual*dt
        s.time_s+=dt
        return {
            'time_s':round(s.time_s,6),
            'raw_request_w':round(raw,3),
            'applied_power_w':round(actual,3),
            'power_limit_w':c.boost_max_w,
            'mode':mode,
            'events':triggered,
            'tier1_c':round(s.tier1_c,3),
            'tier2_c':round(s.tier2_c,3),
            'boost_credit_j':round(s.boost_credit_j,3),
            'clocks':{d:round(s.clock_scale[d],4) for d in DOMAINS},
        }
