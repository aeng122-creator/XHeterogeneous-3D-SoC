"""V3.8 trace ingestion, trace-driven cache replay and bandwidth accounting.

IMPORTANT BOUNDARY NOTES
------------------------
* Intel Pin's pinatrace records *process-virtual operand references*, **not**
  misses at the CPU LLC/HBM entry. Its repetition rate cannot be called HBM hit.
* BoundedHBMLRU accepts only physical-domain HBM_IN input events. Its hit rate
  is a **modeled** hit rate for this cache geometry and replacement policy.
* A GPU ``cycle,bytes`` CSV supplies *traffic demand*, not addresses, cache
  residency or service measurements. GB/s requires a known trace clock.
* Bundled EXAMPLE_SYNTHETIC traces demonstrate formats; they are not captures.

The iter_csv, iter_pin, Access, BoundedHBMLRU and legacy CLI are preserved for
existing V3.8 tests and integrations. A new TraceIngestionEngine adds the
requested high-level CPU and GPU trace analysis without inventing HBM hits,
compression counts, or measured interconnect throughput.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter, OrderedDict
from dataclasses import dataclass
from itertools import chain
from pathlib import Path
from typing import Iterator

LINE_SIZE = 64
AGENTS = ("P", "E", "GPU", "NPU")
BOUNDARIES = ("RAW", "HBM_IN")
PIN_REGEX = re.compile(r"^\s*([RW])\s+(0[xX][0-9a-fA-F]+)\s+(\d+)\b")


@dataclass(frozen=True)
class Access:
    order: int                 # ordering index; NOT clock cycles
    agent: str
    address: int               # byte address in the trace's address domain
    op: str                    # R / W
    boundary: str              # RAW / HBM_IN
    size: int = 1

    def __post_init__(self):
        if self.agent not in AGENTS or self.boundary not in BOUNDARIES:
            raise ValueError("Unsupported agent or boundary")
        if self.address < 0 or self.size <= 0 or self.order < 0 or self.op not in ("R", "W"):
            raise ValueError("Bad trace access")


def _num(value: object) -> int:
    return int(str(value).strip(), 0)


def iter_csv(path: str | Path) -> Iterator[Access]:
    """Stream normalized address events; mandatory: agent,address,op,boundary."""
    with open(path, encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        if not reader.fieldnames or not {"agent", "address", "op", "boundary"}.issubset(reader.fieldnames):
            raise ValueError("CSV requires agent,address,op,boundary; optional order,size")
        for i, record in enumerate(reader):
            if not any((v or "").strip() for v in record.values() if isinstance(v, str)):
                continue
            yield Access(
                order=_num(record["order"]) if record.get("order") else i,
                agent=record["agent"].strip().upper(),
                address=_num(record["address"]),
                op=record["op"].strip().upper(),
                boundary=record["boundary"].strip().upper(),
                size=_num(record["size"]) if record.get("size") else 1,
            )


def iter_pin(path: str | Path, agent: str = "P") -> Iterator[Access]:
    """Read classic Pin ``R 0xADDR SIZE``/``W ...`` text as RAW virtual events."""
    with open(path, encoding="utf-8-sig", errors="replace") as fh:
        count = 0
        for line_no, line in enumerate(fh, 1):
            if not line.strip() or line.lstrip().startswith(("#", "//", "ip")):
                continue
            match = PIN_REGEX.match(line)
            if not match:
                raise ValueError(f"Unsupported Pin memory line {line_no}: {line[:80].rstrip()}")
            op, addr, size = match.groups()
            yield Access(count, agent, int(addr, 16), op, "RAW", int(size))
            count += 1


class BoundedHBMLRU:
    """Finite HBM line-cache *functional proxy*, not timing/coherence model."""

    def __init__(self, capacity_lines: int, line_size: int = LINE_SIZE):
        if capacity_lines <= 0 or line_size <= 0 or line_size & (line_size - 1):
            raise ValueError("Invalid cache geometry")
        self.capacity = capacity_lines
        self.line_size = line_size
        self.lines: OrderedDict[int, bool] = OrderedDict()
        self.stats = Counter()
        self.per_agent = {agent: Counter() for agent in AGENTS}

    def submit(self, access: Access) -> None:
        if access.boundary != "HBM_IN":
            raise ValueError("RAW CPU/GPU operand trace is not HBM input. Filter through L1/L2/L3 first.")
        first = access.address // self.line_size
        last = (access.address + access.size - 1) // self.line_size
        for line in range(first, last + 1):
            hit = line in self.lines
            self.stats["requests"] += 1
            self.per_agent[access.agent]["requests"] += 1
            if hit:
                self.stats["hits"] += 1
                self.per_agent[access.agent]["hits"] += 1
                self.lines.move_to_end(line)
                if access.op == "W":
                    self.lines[line] = True
            else:
                self.stats["misses"] += 1
                self.per_agent[access.agent]["misses"] += 1
                # Write-allocate / read-for-ownership simplification.
                self.stats["ddr_read_bytes"] += self.line_size
                if len(self.lines) == self.capacity:
                    _, dirty = self.lines.popitem(last=False)
                    self.stats["evictions"] += 1
                    if dirty:
                        self.stats["writebacks"] += 1
                        self.stats["ddr_write_bytes"] += self.line_size
                self.lines[line] = access.op == "W"

    def summary(self) -> dict:
        n = self.stats["requests"]
        return {
            "input_boundary": "HBM_IN",
            "model": "bounded_LRU_no_coherence_no_timing",
            "requests": n, "hits": self.stats["hits"], "misses": self.stats["misses"],
            "hit_rate": self.stats["hits"] / n if n else 0.0,
            "resident_lines": len(self.lines), "capacity_lines": self.capacity,
            "evictions": self.stats["evictions"], "writebacks": self.stats["writebacks"],
            "ddr_read_bytes": self.stats["ddr_read_bytes"],
            "ddr_write_bytes": self.stats["ddr_write_bytes"],
            "per_agent": {
                name: {"requests": counts["requests"], "hits": counts["hits"],
                       "misses": counts["misses"]}
                for name, counts in self.per_agent.items()
            },
        }


class TraceIngestionEngine:
    """Read externally captured traces with explicit address and timing provenance."""

    def __init__(self, trace_dir: str | Path = "traces", *,
                 capacity_lines: int = 65536, clock_ghz: float = 2.5,
                 sustainable_memory_gbs: float = 204.79):
        if capacity_lines < 1 or clock_ghz <= 0 or sustainable_memory_gbs <= 0:
            raise ValueError("Invalid cache capacity, trace clock or memory bandwidth budget")
        self.trace_dir = Path(trace_dir)
        self.hbm_cache_line_size = LINE_SIZE
        self.capacity_lines = capacity_lines
        self.clock_ghz = float(clock_ghz)
        self.sustainable_memory_gbs = float(sustainable_memory_gbs)

    def _path(self, filename: str | Path) -> Path:
        path = Path(filename)
        return path if path.is_absolute() or path.is_file() else self.trace_dir / path

    @staticmethod
    def _synthetic_notice(path: Path) -> str | None:
        return "BUNDLED_SYNTHETIC_EXAMPLE_NOT_REAL_WORKLOAD" if "SYNTHETIC" in path.name.upper() else None

    def ingest_cpu_pinatrace(self, filename: str = "EXAMPLE_SYNTHETIC_pinatrace.txt") -> dict:
        """Analyze Pin raw virtual operand reuse, NOT HBM hit rate.

        The bounded LRU is only an operand-locality proxy. For HBM hit rate,
        replay already-filtered HBM_IN records with ingest_hbm_address_trace().
        """
        path = self._path(filename)
        if not path.is_file():
            return {"status": "Error", "message": f"CPU trace not found: {path}"}
        cache: OrderedDict[int, None] = OrderedDict()
        ops = 0
        line_accesses = 0
        reused_lines = 0
        for event in iter_pin(path):
            ops += 1
            first = event.address // LINE_SIZE
            last = (event.address + event.size - 1) // LINE_SIZE
            for line in range(first, last + 1):
                line_accesses += 1
                if line in cache:
                    reused_lines += 1
                    cache.move_to_end(line)
                else:
                    if len(cache) >= self.capacity_lines:
                        cache.popitem(last=False)
                    cache[line] = None
        return {
            "status": "RAW_TRACE_ONLY",
            "Trace Source": str(path),
            "Trace Format": "CPU Intel Pin pinatrace (virtual addresses)",
            "Total Trace Instructions": None,  # Pin memory-only logs cannot count retired instructions
            "Total Memory Operands": ops,
            "64B Line References": line_accesses,
            "Bounded RAW Operand Reuse Ratio": round(100 * reused_lines / line_accesses, 2)
            if line_accesses else 0.0,
            "Dynamic HBM Hit Rate": None,
            "Cache Compressions Triggered": None,
            "Trace Warning": "RAW Pin operands are not LLC/HBM misses; compression cannot be derived from addresses.",
            "Dataset Notice": self._synthetic_notice(path),
        }

    def ingest_hbm_address_trace(self, filename: str | Path) -> dict:
        """Replay normalized CSV with boundary=HBM_IN, computing *modeled* HBM hit."""
        path = self._path(filename)
        if not path.is_file():
            return {"status": "Error", "message": f"HBM input trace not found: {path}"}
        cache = BoundedHBMLRU(self.capacity_lines)
        for event in iter_csv(path):
            cache.submit(event)
        result = cache.summary()
        result.update({
            "status": "OK_MODELLED_HBM_CACHE_REPLAY",
            "Trace Source": str(path),
            "Dynamic HBM Hit Rate": f"{100 * result['hit_rate']:.2f}%",
            "Dataset Notice": self._synthetic_notice(path),
            "Verification Note": "Modelled LRU hit rate conditional on HBM_IN boundary, capacity and assumed policies; not silicon-measured.",
        })
        return result

    def ingest_gpu_hbm_trace(self, filename: str = "EXAMPLE_SYNTHETIC_hbm_in.csv") -> dict:
        """Parse GPU ``cycle,bytes`` traffic CSV OR normalized HBM_IN event CSV.

        A normalized address trace without explicit cycle timestamps supports
        modeled HBM residency, **not** GB/s. A cycle/bytes trace supports GB/s,
        but cannot derive hits because it has no addresses.
        """
        path = self._path(filename)
        if not path.is_file():
            return {"status": "Error", "message": f"GPU trace not found: {path}"}
        with path.open(encoding="utf-8-sig", newline="") as fh:
            rows = (r for r in csv.reader(fh) if r and any(v.strip() for v in r)
                    and not r[0].lstrip().startswith("#"))
            first = next(rows, None)
            if first is None:
                return {"status": "EMPTY_TRACE", "Trace Source": str(path)}
            lower = [x.strip().lower() for x in first]
            if {"agent", "address", "op", "boundary"}.issubset(lower):
                # Reopen as a streamed DictReader through existing stable parser.
                report = self.ingest_hbm_address_trace(path)
                if report.get("status") == "OK_MODELLED_HBM_CACHE_REPLAY":
                    report["GPU HBM Hit Rate"] = (
                        f"{100 * report['per_agent']['GPU']['hits'] / report['per_agent']['GPU']['requests']:.2f}%"
                        if report["per_agent"]["GPU"]["requests"] else None
                    )
                report["Average Bandwidth Demand"] = None
                report["NoC Traffic Condition"] = "UNDETERMINED: no cycle timestamps or network model"
                return report
            if "cycle" in lower and "bytes" in lower:
                ci, bi = lower.index("cycle"), lower.index("bytes")
                data_rows = rows
            else:
                ci, bi = 0, 1  # Headerless: cycle,bytes
                data_rows = chain([first], rows)

            total_bytes = 0
            count = 0
            first_cycle = None
            last_cycle = None
            for line_no, row in enumerate(data_rows, 2):
                if max(ci, bi) >= len(row):
                    raise ValueError(f"GPU CSV row {line_no} lacks cycle or bytes")
                cycle = int(row[ci].strip(), 0)
                byte_count = int(row[bi].strip(), 0)
                if cycle < 0 or byte_count < 0:
                    raise ValueError(f"GPU CSV row {line_no} has negative cycle/bytes")
                if last_cycle is not None and cycle < last_cycle:
                    raise ValueError(f"GPU CSV must be ordered by cycle (row {line_no})")
                if first_cycle is None:
                    first_cycle = cycle
                last_cycle = cycle
                count += 1
                total_bytes += byte_count
        if count == 0:
            return {"status": "EMPTY_TRACE", "Trace Source": str(path)}
        # Decimal GB/s: bytes / (span_cycles / (clock_ghz*1e9)) / 1e9.
        span_cycles = last_cycle - first_cycle + 1
        gbps = total_bytes * self.clock_ghz / span_cycles
        return {
            "status": "OK_TRACE_DEMAND",
            "Trace Source": str(path),
            "Trace Format": "cycle,bytes demand samples",
            "Samples": count,
            "Simulated Cycles": span_cycles,
            "Total Requested Bytes": total_bytes,
            "Clock GHz (provided assumption)": self.clock_ghz,
            "Average Bandwidth Demand": f"{gbps:.2f} GB/s",
            "Average Bandwidth Demand GBps": gbps,
            "Demand vs Assumed Memory Budget": (
                "Above assumed budget" if gbps > self.sustainable_memory_gbs else "Within assumed budget"
            ),
            "NoC Traffic Condition": "NOT_EVALUATED: memory demand is not NoC service/latency",
            "Dynamic HBM Hit Rate": None,
            "Dataset Notice": self._synthetic_notice(path),
        }


def cli(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", nargs="?", type=Path,
                        help="Legacy normalized CSV or Pin trace. Optional in multi-file mode")
    parser.add_argument("--format", choices=["csv", "pin"], default="csv")
    parser.add_argument("--pin-agent", choices=AGENTS, default="P")
    parser.add_argument("--capacity-lines", type=int, default=64,
                        help="bounded test proxy (NOT physical HBM capacity)")
    parser.add_argument("--trace-dir", type=Path, default=Path("traces"))
    parser.add_argument("--cpu-trace", type=str, help="Pin text filename/path")
    parser.add_argument("--gpu-trace", type=str, help="GPU cycle,bytes or normalized HBM_IN CSV")
    parser.add_argument("--hbm-input", type=str, help="normalized HBM_IN CSV")
    parser.add_argument("--clock-ghz", type=float, default=2.5)
    parser.add_argument("--sustainable-memory-gbs", type=float, default=204.79)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    engine = TraceIngestionEngine(
        args.trace_dir, capacity_lines=args.capacity_lines,
        clock_ghz=args.clock_ghz,
        sustainable_memory_gbs=args.sustainable_memory_gbs,
    )
    if args.input:
        if args.format == "pin":
            summary = engine.ingest_cpu_pinatrace(args.input)
            summary["Agent"] = args.pin_agent
        else:
            summary = engine.ingest_hbm_address_trace(args.input)
    else:
        summary = {}
        if args.cpu_trace:
            summary["cpu"] = engine.ingest_cpu_pinatrace(args.cpu_trace)
        if args.gpu_trace:
            summary["gpu"] = engine.ingest_gpu_hbm_trace(args.gpu_trace)
        if args.hbm_input:
            summary["hbm"] = engine.ingest_hbm_address_trace(args.hbm_input)
        if not summary:
            parser.error("Provide an input file or --cpu-trace / --gpu-trace / --hbm-input")
    rendered = json.dumps(summary, indent=2, ensure_ascii=False)
    print(rendered)
    if args.output:
        args.output.parent.mkdir(exist_ok=True, parents=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    return summary


if __name__ == "__main__":
    cli()
