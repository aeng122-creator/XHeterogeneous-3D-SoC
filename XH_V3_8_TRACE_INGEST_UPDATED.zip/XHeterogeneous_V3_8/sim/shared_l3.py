"""V3.5 shared non-inclusive L3 bank prototype: CPU96MiB + GPU16MiB soft regions.

Each of eight banks has 14 MiB physically, CPU target 12 MiB, GPU target 2 MiB.
Idle capacity may be borrowed. Under pressure, over-quota lines are first
victims. Non-inclusive is an intended policy: no directory or coherence RTL.
"""
from collections import OrderedDict,Counter

class BorrowableL3Bank:
    def __init__(self,total_bytes:int,cpu_soft_bytes:int,gpu_soft_bytes:int):
        if cpu_soft_bytes+gpu_soft_bytes!=total_bytes or min(total_bytes,cpu_soft_bytes,gpu_soft_bytes)<1:
            raise ValueError('Each soft quota must be positive and sum to total')
        self.capacity=total_bytes
        self.target={'CPU':cpu_soft_bytes,'GPU':gpu_soft_bytes}
        self.used={'CPU':0,'GPU':0}
        self.entries=OrderedDict()
        self.stats=Counter()
    @staticmethod
    def footprint(line:int):
        return 32 if ((line*2654435761)&7)<4 else 64
    def get(self,line,owner):
        key=(owner,line)
        if key in self.entries:
            self.entries.move_to_end(key)
            return True
        return False
    def put(self,line,owner):
        if owner not in self.target:raise ValueError(owner)
        key=(owner,line)
        if key in self.entries:
            self.entries.move_to_end(key)
            return
        size=self.footprint(line)
        while sum(self.used.values())+size>self.capacity:
            excess={c:self.used[c]-self.target[c] for c in self.target}
            priority=([c for c,v in excess.items() if v>0])
            if priority:
                victim_owner=max(priority,key=lambda c:excess[c])
                victim=next(k for k in self.entries if k[0]==victim_owner)
            else:
                victim=next(iter(self.entries))
            old_size=self.entries.pop(victim)
            self.used[victim[0]]-=old_size
            self.stats['evictions']+=1
        self.entries[key]=size
        self.used[owner]+=size
        if self.used['GPU']>self.target['GPU']:
            self.stats['gpu_borrowed_highwater']=max(self.stats['gpu_borrowed_highwater'],self.used['GPU']-self.target['GPU'])
        if self.used['CPU']>self.target['CPU']:
            self.stats['cpu_borrowed_highwater']=max(self.stats['cpu_borrowed_highwater'],self.used['CPU']-self.target['CPU'])
