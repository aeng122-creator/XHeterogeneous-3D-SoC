"""Xe2-LPG / Intel Arc 140V-class *analytic* GPU roofline, not a GPU simulator.

The 8 Xe cores, 64 vector engines and 1.95 GHz reference are from Intel.
The assumed SIMD width and FMAs per cycle create an IDEAL FP32 upper bound.
Utilization and DDR shares are adjustable *hypothetical* inputs, not benchmarks.
This model cannot predict ray-tracing, texture, rasterizer or Blender behavior.
"""
from dataclasses import dataclass, asdict
from math import isfinite

@dataclass(frozen=True)
class Arc140VProxy:
    xe_cores: int = 8
    vector_engines_per_xe: int = 8
    max_clock_ghz: float = 1.95
    simd_fp32_lanes_per_vector: int = 16  # illustrative; not a verified Xe2 issue rate
    fp32_ops_per_fma: int = 2
    shared_ddr_peak_gbs: float = 179.2
    shared_ddr_sustained_proxy_gbs: float = 140.0

    @property
    def vector_engines(self) -> int:
        return self.xe_cores * self.vector_engines_per_xe

    @property
    def ideal_fp32_tflops(self) -> float:
        return (self.vector_engines * self.simd_fp32_lanes_per_vector *
                self.fp32_ops_per_fma * self.max_clock_ghz / 1000)

    def roofline(self, width:int=7680,height:int=4320,flops_per_pixel:float=1000,
                 external_bytes_per_pixel:float=32,compute_utilization:float=.55,
                 ddr_gpu_share:float=.45,clock_scale:float=1.) -> dict:
        if width<=0 or height<=0 or flops_per_pixel<=0 or external_bytes_per_pixel<=0:
            raise ValueError('Positive dimensions/work required')
        if any(not (0 < x <= 1 and isfinite(x)) for x in (compute_utilization,ddr_gpu_share,clock_scale)):
            raise ValueError('Fractions must be in (0,1]')
        pixels=width*height
        compute_tf=self.ideal_fp32_tflops*compute_utilization*clock_scale
        allocated_bw=self.shared_ddr_sustained_proxy_gbs*ddr_gpu_share
        compute_seconds=(pixels*flops_per_pixel)/(compute_tf*1e12)
        memory_seconds=(pixels*external_bytes_per_pixel)/(allocated_bw*1e9)
        lower_bound_seconds=max(compute_seconds,memory_seconds)
        return {'pixels':pixels,'ideal_peak_fp32_tflops':round(self.ideal_fp32_tflops,3),
                'assumed_compute_utilization':compute_utilization,
                'assumed_gpu_clock_scale':clock_scale,
                'gpu_effective_fp32_tflops_proxy':round(compute_tf,3),
                'assumed_gpu_ddr_share':ddr_gpu_share,
                'gpu_allocated_ddr_gbs_proxy':round(allocated_bw,3),
                'compute_only_lower_bound_ms':round(compute_seconds*1e3,3),
                'memory_only_lower_bound_ms':round(memory_seconds*1e3,3),
                'roofline_frame_time_lower_bound_ms':round(lower_bound_seconds*1e3,3),
                'roofline_fps_upper_bound':round(1/lower_bound_seconds,3),
                'warning':'Optimistic roofline only; no raster/RT/driver/texture/CPU or full render pipeline modeled.'}

if __name__=='__main__':
    import json
    gpu=Arc140VProxy()
    print(json.dumps({'gpu':asdict(gpu),'light':gpu.roofline(),
                      'heavy':gpu.roofline(flops_per_pixel=20000,external_bytes_per_pixel=128)},indent=2))
