"""V3.7 HBM/vertical-fabric/power/thermal verification *proxy*.

No PDK, measured IP power, physical TSV delay, actual silicon traces, RTL,
coherence protocol timing, or formal NoC deadlock proof are provided.
This module makes testable assumptions explicit and flags unsafe cases.
"""
from __future__ import annotations

from collections import Counter, OrderedDict
from dataclasses import dataclass, field
import csv
import json
import math
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

LINE_BYTES = 64
AGENTS = ("P", "E", "GPU", "NPU")


@dataclass(frozen=True)
class TraceAccess:
    cycle: int
    agent: str
    address: int  # byte address
    operation: str = "R"
    value: int = 0  # one abstract token per cache line; NOT a byte-accurate payload

    def __post_init__(self):
        if self.cycle < 0 or self.address < 0 or self.agent not in AGENTS:
            raise ValueError("Invalid cycle/address/agent")
        if self.operation not in ("R", "W"):
            raise ValueError("Operation must be R or W")


def read_trace_csv(path: str | Path) -> List[TraceAccess]:
    """Read a memory-reference trace: cycle,agent,address,operation,value.

    Values are abstract per-line tokens for functional coherency tests.
    This does not generate a REAL trace or claim a workload is realistic.
    """
    out = []
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            out.append(TraceAccess(
                cycle=int(row["cycle"]), agent=row["agent"],
                address=int(row["address"], 0),
                operation=row.get("operation", "R") or "R",
                value=int(row.get("value", "0") or "0", 0)
            ))
    return sorted(out, key=lambda e: e.cycle)


@dataclass
class CacheLine:
    token: int
    dirty: bool = False


@dataclass(frozen=True)
class CacheResult:
    hit: bool
    token: int
    invalidations: int
    ownership_transfer: bool
    dirty_writeback: bool


class HBMLineCache:
    """Bounded tag-based HBM L4, with LRU eviction and DDR writebacks.

    Logical one-token-per-line data is sufficient for ordering/invariant tests;
    it is NOT a hardware MESI/MOESI protocol or byte-accurate memory model.
    All agents are serialized at this model interface. It tracks ownership and
    invalidations, but does NOT model private L1/L2, MSHRs, ordering/fences,
    snoop delays, races or coherence message traffic.
    """

    def __init__(self, capacity_lines: int):
        if capacity_lines < 1:
            raise ValueError("HBM capacity must be positive")
        self.capacity_lines = capacity_lines
        self.lines: OrderedDict[int, CacheLine] = OrderedDict()
        self.ddr: Dict[int, int] = {}
        self.sharers: Dict[int, set[str]] = {}
        self.writer: Dict[int, str] = {}
        self.counters = Counter()
        self.results_by_agent: Dict[str, Counter] = {a: Counter() for a in AGENTS}

    def access(self, event: TraceAccess) -> CacheResult:
        address = event.address // LINE_BYTES
        owner = event.agent
        hit = address in self.lines
        writeback = False
        if hit:
            self.counters["hits"] += 1
            self.results_by_agent[owner]["hits"] += 1
            self.lines.move_to_end(address)
        else:
            self.counters["misses"] += 1
            self.results_by_agent[owner]["misses"] += 1
            self.counters["ddr_reads"] += 1
            if len(self.lines) == self.capacity_lines:
                evicted_addr, victim = self.lines.popitem(last=False)
                self.counters["evictions"] += 1
                if victim.dirty:
                    self.ddr[evicted_addr] = victim.token
                    self.counters["ddr_writebacks"] += 1
                    writeback = True
                self.sharers.pop(evicted_addr, None)
                self.writer.pop(evicted_addr, None)
            self.lines[address] = CacheLine(self.ddr.get(address, 0))
        old_sharers = self.sharers.get(address, set())
        old_writer = self.writer.get(address)
        invalidations = 0
        transfer = old_writer is not None and old_writer != owner
        if event.operation == "W":
            invalidations = len(old_sharers - {owner})
            self.counters["invalidations"] += invalidations
            self.lines[address].token = event.value
            self.lines[address].dirty = True
            self.sharers[address] = {owner}
            self.writer[address] = owner
            self.counters["writes"] += 1
        else:
            self.sharers.setdefault(address, set()).add(owner)
            if transfer:
                self.writer.pop(address, None)  # serialized downgrade in proxy
                self.counters["owner_downgrades"] += 1
            self.counters["reads"] += 1
        self.counters["requests"] += 1
        if transfer:
            self.counters["ownership_transfers"] += 1
        self.validate()
        return CacheResult(hit, self.lines[address].token, invalidations, transfer, writeback)

    def validate(self):
        if len(self.lines) > self.capacity_lines:
            raise AssertionError("Cache capacity exceeded")
        for address, owner in self.writer.items():
            if address not in self.lines or self.sharers.get(address) != {owner}:
                raise AssertionError("Exclusive writer invariant broken")
        for address in self.sharers:
            if address not in self.lines:
                raise AssertionError("Stale directory entry")

    def flush(self):
        for address, line in self.lines.items():
            if line.dirty:
                self.ddr[address] = line.token
                line.dirty = False
                self.counters["ddr_writebacks"] += 1

    def run(self, trace: Iterable[TraceAccess]):
        output = []
        for event in trace:
            result = self.access(event)
            output.append((event, result))
        return output

    def summary(self):
        requests = self.counters["requests"]
        return {
            "requests": requests,
            "hits": self.counters["hits"],
            "misses": self.counters["misses"],
            "hit_rate": self.counters["hits"] / requests if requests else 0.0,
            "ddr_read_bytes": self.counters["ddr_reads"] * LINE_BYTES,
            "ddr_writeback_bytes": self.counters["ddr_writebacks"] * LINE_BYTES,
            "evictions": self.counters["evictions"],
            "invalidations": self.counters["invalidations"],
            "ownership_transfers": self.counters["ownership_transfers"],
            "per_agent": {a: dict(v) for a, v in self.results_by_agent.items()},
            "capacity_lines": self.capacity_lines,
            "resident_lines": len(self.lines),
        }


@dataclass(frozen=True)
class Packet:
    cycle: int
    source: Tuple[int, int]  # (x,y) in 8x4 XY mesh
    agent: str
    packet_id: int


class VerticalFabric:
    """Cycle-indexed gateway service with finite virtual queue and backpressure.

    XY paths, 4-cycle TSV delay, buffer depth, one flit/packet are ASSUMED;
    this does not simulate router credit/VC dependencies and cannot PROVE
    channel-level deadlock freedom. The escape VC is a one-way deterministic
    XY fallback; no switching from escape back to adaptive VC is allowed.
    """

    def __init__(self, gateways=None, depth=64, service_cycles=1,
                 tsv_latency_cycles=4):
        self.gateways = list(gateways or [(1, 0), (6, 0), (1, 3), (6, 3)])
        self.depth = depth
        self.service_cycles = service_cycles
        self.tsv_latency_cycles = tsv_latency_cycles
        if not self.gateways or depth < 1 or service_cycles < 1 or tsv_latency_cycles < 1:
            raise ValueError("Invalid gateway parameters")
        self.next_free = [0] * len(self.gateways)
        self.stats = Counter()
        self.latencies = []
        self.routes = []

    @staticmethod
    def xy_path(src, dst):
        x, y = src
        ex, ey = dst
        path = [(x, y)]
        while x != ex:
            x += 1 if ex > x else -1
            path.append((x, y))
        while y != ey:
            y += 1 if ey > y else -1
            path.append((x, y))
        return path

    def route(self, packet: Packet, adaptive=True):
        if packet.cycle < 0 or packet.agent not in AGENTS:
            raise ValueError("Invalid packet")
        if packet.agent in ("GPU", "NPU"):
            # local upper tier accesses have no TSV crossing
            self.stats["upper_tier_local"] += 1
            return {"packet_id": packet.packet_id, "latency": 2,
                    "gateway": None, "vc": "local", "path": [], "backpressure": 0}
        nearest = min(range(len(self.gateways)),
                      key=lambda i: (len(self.xy_path(packet.source, self.gateways[i])), i))
        choices = range(len(self.gateways)) if adaptive else [nearest]
        candidates = []
        for i in choices:
            path = self.xy_path(packet.source, self.gateways[i])
            hops = len(path) - 1
            ready = packet.cycle + hops
            queued = max(0, (self.next_free[i] - ready + self.service_cycles - 1) // self.service_cycles)
            backpressure = max(0, queued - self.depth + 1) * self.service_cycles
            admitted = ready + backpressure
            start = max(admitted, self.next_free[i])
            done = start + self.service_cycles + self.tsv_latency_cycles
            candidates.append((done, len(path), i, path, backpressure, start))
        _, _, chosen, path, backpressure, start = min(candidates)
        done = start + self.service_cycles + self.tsv_latency_cycles
        self.next_free[chosen] = start + self.service_cycles
        escape = adaptive and chosen != nearest
        self.stats["packets"] += 1
        self.stats["escape_packets"] += int(escape)
        self.stats["backpressure_cycles"] += backpressure
        self.stats["max_latency"] = max(self.stats["max_latency"], done - packet.cycle)
        if len(set(path)) != len(path):
            raise AssertionError("XY route contained a routing loop")
        latency = done - packet.cycle
        self.latencies.append(latency)
        self.routes.append((packet.packet_id, chosen, "escape_xy" if escape else "adaptive_xy"))
        return {"packet_id": packet.packet_id, "latency": latency,
                "gateway": chosen, "vc": "escape_xy" if escape else "adaptive_xy",
                "path": path, "backpressure": backpressure}

    def summary(self):
        lat = sorted(self.latencies)
        pct = lambda q: lat[math.ceil(q * len(lat))-1] if lat else None
        return {"packets": self.stats["packets"],
                "escape_packets": self.stats["escape_packets"],
                "upper_tier_local": self.stats["upper_tier_local"],
                "backpressure_cycles": self.stats["backpressure_cycles"],
                "p95_cycles": pct(.95), "p99_cycles": pct(.99),
                "max_cycles": self.stats["max_latency"],
                "assumed_tsv_latency_cycles": self.tsv_latency_cycles}


class ThermalNetwork:
    """Multi-node lumped thermal RC ODE, parameters from versioned JSON.

    Temperatures are lumped node averages, not hotspots or CFD verification.
    """
    def __init__(self, config_path):
        self.config = json.loads(Path(config_path).read_text(encoding="utf8"))
        self.nodes = self.config["nodes"]
        self.edges = self.config["resistances_K_per_W"]
        self.coolant = float(self.config["coolant_C"])
        self.temps = {k: self.coolant for k in self.nodes}
        for n, value in self.nodes.items():
            if value["C_J_per_K"] <= 0:
                raise ValueError("Nonpositive thermal capacitance")
        for e in self.edges:
            if e["R"] <= 0:
                raise ValueError("Nonpositive thermal resistance")

    def step(self, power_by_node: Dict[str, float], dt_s: float):
        if dt_s <= 0 or any(p < 0 for p in power_by_node.values()):
            raise ValueError("Invalid thermal step/power")
        unknown = set(power_by_node) - set(self.nodes)
        if unknown:
            raise ValueError(f"Unknown thermal node(s): {unknown}")
        # Substep sufficiently for stable explicit integration across edges.
        strengths = {n: 0.0 for n in self.nodes}
        for e in self.edges:
            strengths[e["a"]] += 1/e["R"]
            if e["b"] != "coolant": strengths[e["b"]] += 1/e["R"]
        stable = min(self.nodes[n]["C_J_per_K"] / max(1e-10, strengths[n])
                     for n in self.nodes) * .15
        count = max(1, math.ceil(dt_s/stable))
        sub = dt_s/count
        for _ in range(count):
            updated = {}
            for n, node in self.nodes.items():
                flux = power_by_node.get(n, 0.)
                for e in self.edges:
                    if e["a"] == n:
                        target = self.coolant if e["b"] == "coolant" else self.temps[e["b"]]
                    elif e["b"] == n:
                        target = self.temps[e["a"]]
                    else:
                        continue
                    flux += (target-self.temps[n]) / e["R"]
                updated[n] = self.temps[n] + sub*flux/node["C_J_per_K"]
            self.temps = updated
        return dict(self.temps)


@dataclass
class PowerConfig:
    sustained_w: float = 120.0
    preventive_w: float = 170.0
    boost_w: float = 180.0
    preventive_target_w: float = 176.0
    boost_credit_j: float = 120.0
    thermal_guard_c: float = 90.0
    thermal_trip_c: float = 105.0
    dvfs_floor: float = 0.35
    exponent: float = 2.2  # assumed effective P=f^alpha relation


class AdvancedMemoryAndThermalCore:
    """Power/thermal closed-loop *proxy*, with explicit infeasibility reporting.

    Takes independent demand per P/E/GPU/NPU domain (dynamic power at f=1),
    and fixed cache/NoC/IO/HBM baseline plus any static leakage. It does not
    infer power from memory traffic, nor claim calibration to a transistor PDK.
    """
    def __init__(self, thermal_config_path="config/thermal_rc.json", config=None):
        path = Path(thermal_config_path)
        if not path.is_file():
            path = Path(__file__).resolve().parents[1] / thermal_config_path
        self.thermal = ThermalNetwork(path)
        self.cfg = config or PowerConfig()
        self.boost_credit_j = self.cfg.boost_credit_j
        self.time_s = 0.0
        self.latched_trip = False
        self.sensor_fault = False
        self.last_result = {}
        # Compatibility with the V3.7 user-supplied example API.
        self.mesh_frequency_ghz = 2.5  # nominal *assumed*, not measured
        self.tsv_latency_cycles = 4     # assumed, NOT actual TSV delay
        self.power_cap_w = self.cfg.sustained_w
        self.escape_vc_active_count = 0
        self._legacy_hbm = None
        self._legacy_fabric = None
        self._legacy_working_set_mib = None

    def calculate_dynamic_hbm_hit_rate(self, memory_address, working_set_size_mb=32):
        """Backward-compatible trace-fed *HBM cache* hit fraction.

        `memory_address` is a byte address, not a line id. Capacity uses the
        caller's MiB parameter, and hits only count if the tag is resident.
        To avoid enormous tag allocations a sparse LRU map is used.
        """
        if working_set_size_mb <= 0:
            raise ValueError("Capacity must be positive")
        if self._legacy_hbm is None or self._legacy_working_set_mib != working_set_size_mb:
            self._legacy_hbm = HBMLineCache(int(working_set_size_mb * 1024**2 // LINE_BYTES))
            self._legacy_working_set_mib = working_set_size_mb
        self._legacy_hbm.access(TraceAccess(self._legacy_hbm.counters["requests"],"P",memory_address))
        return self._legacy_hbm.summary()["hit_rate"]

    def simulate_interconnect_tier(self, packet_volume, vertical_buffer_limit=64):
        """Backward-compatible packet burst timing proxy, returns P95 cycles.

        NO implication that 4 assumed TSV cycles are physically characterized.
        """
        if packet_volume < 0:
            raise ValueError("Negative packet volume")
        self._legacy_fabric = VerticalFabric(depth=vertical_buffer_limit,
                                              tsv_latency_cycles=self.tsv_latency_cycles)
        for i in range(packet_volume):
            self._legacy_fabric.route(Packet(0,(1,0),"P",i),adaptive=True)
        self.escape_vc_active_count += self._legacy_fabric.summary()["escape_packets"]
        return self._legacy_fabric.summary()["p95_cycles"] or 0

    def enforce_120w_thermal_limit(self, static_power_w, dynamic_traffic_intensity):
        """Backward-compatible 120W-only mode for the supplied usage example.

        Original traffic^2 model is retained solely as an *uncalibrated input*.
        When a frequency limit cannot meet power, explicit duty-cycle stalls
        or infeasibility are reported; never claim a fake safe frequency.
        """
        if dynamic_traffic_intensity < 0:
            raise ValueError("Negative traffic intensity")
        dynamic = dynamic_traffic_intensity * self.mesh_frequency_ghz**2 * 15.5
        self.boost_credit_j = 0.0  # force PL1; not a PL2 / boost measurement
        d = {"P":dynamic*.3,"E":dynamic*.25,"GPU":dynamic*.35,"NPU":dynamic*.1}
        result = self.run_step(d,{"static":static_power_w},dt_s=.1)
        return {"Enforced Frequency (GHz)":round(self.mesh_frequency_ghz * result["dvfs_frequency_scale"],3),
                "Total Modeled Power (W)":result["applied_power_w"],
                "Power Cap Met":result["power_cap_met"],
                "Active Duty Fraction":result["active_duty_fraction"],
                "Escape VC Deflections":self.escape_vc_active_count,
                "Thermal Model State":result["mode"],
                "Caution":"Uncalibrated demand estimate; not a real thermal or power measurement"}

    def run_step(self, dynamic_domain_w: Dict[str,float],
                 fixed_power_w: Dict[str,float], dt_s=0.1,
                 sensor_ok=True):
        c = self.cfg
        if dt_s <= 0 or set(dynamic_domain_w) != set(AGENTS) or any(p < 0 for p in dynamic_domain_w.values()):
            raise ValueError("Expected nonnegative demand for P,E,GPU,NPU")
        if any(p < 0 for p in fixed_power_w.values()):
            raise ValueError("Negative fixed power")
        fixed = sum(fixed_power_w.values())
        dynamic = sum(dynamic_domain_w.values())
        raw = fixed + dynamic
        if not sensor_ok: self.sensor_fault = True
        current_temp = max(self.thermal.temps.values())
        if current_temp >= c.thermal_trip_c: self.latched_trip = True
        reason = []
        if self.latched_trip or self.sensor_fault:
            reason.append("THERMAL_TRIP" if self.latched_trip else "SENSOR_FAULT")
            # Tripped state is not 0 W: fixed leakage/always-on domains remain.
            target = 0.0
            dvfs = 0.0
            duty = 0.0
            applied = fixed
            feasible = fixed <= c.sustained_w
        else:
            target = c.boost_w
            if raw > c.preventive_w:
                target = min(target, c.preventive_target_w,
                             raw - .1*(raw-c.preventive_w))
                reason.append("PREVENTIVE_DVFS")
            target = min(target, c.sustained_w+self.boost_credit_j/dt_s)
            if self.boost_credit_j <= 1e-9:
                reason.append("SUSTAINED_120W")
            if current_temp >= c.thermal_guard_c:
                target = min(target, c.sustained_w)
                reason.append("THERMAL_GUARD")
            if raw <= target:
                dvfs = duty = 1.0
                applied = raw
                feasible = True
            elif fixed >= target:
                # No fake compliance: independent fixed power exceeds budget.
                dvfs = duty = 0.0
                applied = fixed
                feasible = False
                reason.append("INFEASIBLE_FIXED_POWER")
            else:
                allowable = target-fixed
                floor_dynamic = dynamic*(c.dvfs_floor**c.exponent)
                if floor_dynamic <= allowable:
                    dvfs = max(c.dvfs_floor, (allowable/dynamic)**(1/c.exponent)) if dynamic else 1.0
                    duty = 1.0
                    applied = fixed+dynamic*(dvfs**c.exponent)
                else:
                    dvfs = c.dvfs_floor
                    # Idealized clock/duty gating: does not reduce fixed power.
                    duty = allowable/floor_dynamic
                    applied = fixed+floor_dynamic*duty
                    reason.append("DUTY_CYCLE_STALL")
                feasible = True
        if feasible and applied>c.boost_w+1e-7:
            raise AssertionError("Modeled cap violated")
        # Energy accounting and thermal node loads; dynamic P/E on bottom,
        # GPU/NPU top; separate on-interposer HBM; remainder on copper/top.
        used_boost = max(0, applied-c.sustained_w)*dt_s
        replenished = max(0, c.sustained_w-applied)*dt_s
        self.boost_credit_j = min(c.boost_credit_j,
                                  max(0, self.boost_credit_j-used_boost+replenished))
        active_multiplier = (dvfs**c.exponent)*duty
        bottom = (dynamic_domain_w["P"]+dynamic_domain_w["E"])*active_multiplier
        upper = (dynamic_domain_w["GPU"]+dynamic_domain_w["NPU"])*active_multiplier
        hbm = fixed_power_w.get("HBM",0.0)
        rest = fixed-hbm
        powers = {"bottom_cpu_tier":bottom+rest*.4,
                  "top_gpu_l3_tier":upper+rest*.6,
                  "adjacent_hbm3_stack":hbm,
                  "stepped_copper_plate":0.0}
        temps = self.thermal.step(powers,dt_s)
        self.time_s+=dt_s
        self.last_result = {"time_s":round(self.time_s,4),
            "raw_request_w":round(raw,3),"applied_power_w":round(applied,3),
            "power_cap_met":bool(feasible and applied<=c.boost_w+1e-7),
            "current_target_w":round(target,3),
            "dvfs_frequency_scale":round(dvfs,5),
            "active_duty_fraction":round(duty,5),
            "boost_credit_j":round(self.boost_credit_j,4),
            "mode":"INFEASIBLE" if not feasible else ("TRIPPED" if self.latched_trip or self.sensor_fault else "LIMITED" if applied<raw-1e-5 else "NORMAL"),
            "events":reason, "temps_C":{k:round(v,3) for k,v in temps.items()},
            "power_by_node_w":{k:round(v,3) for k,v in powers.items()}}
        return dict(self.last_result)
