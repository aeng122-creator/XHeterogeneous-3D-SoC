"""Cycle-stepped external-memory scheduling proxy for X-Heterogeneous V3.5.

NOT a JEDEC command-accurate LPDDR5X/DDR5 simulator. Four 64-bit DDR5
channels vs eight 32-bit LPDDR5X subchannels are conceptual configurations.
Work-conserving weighted byte-fair scheduling and bandwidth credits replace the
V3.4 unrealistic single-queue ceil(64 / aggregate_bytes_per_cycle) service.
"""
from __future__ import annotations
from collections import Counter, deque
from dataclasses import dataclass, field
from math import isfinite

CLOCK_HZ = 2_500_000_000
QOS = {'P': .30, 'E': .125, 'GPU': .50, 'NPU': .075}
ORDER = ('P', 'E', 'GPU', 'NPU')

@dataclass(frozen=True)
class MemoryConfig:
    name: str
    mtps: int
    width_bits: int
    channels: int
    efficiency: float = .75
    gpu_compress_fraction: float = 0.
    gpu_compression_ratio: float = .5
    gpu_codec_cycles: int = 3
    fixed_latency_cycles: int = 85
    qos_weights: dict = field(default_factory=lambda: dict(QOS))

    def __post_init__(self):
        if self.width_bits <= 0 or self.mtps <= 0 or self.channels <= 0:
            raise ValueError('Positive memory bandwidth and channels required')
        if self.width_bits % self.channels or self.channels & (self.channels - 1):
            raise ValueError('Power-of-two channels with integer bits/channel required')
        if not (0 < self.efficiency <= 1 and 0 <= self.gpu_compress_fraction <= 1):
            raise ValueError('Invalid efficiency or GPU compression fraction')
        if not (0 < self.gpu_compression_ratio <= 1):
            raise ValueError('Compression ratio must be in (0,1]')
        if any(v <= 0 for v in self.qos_weights.values()) or set(self.qos_weights) != set(ORDER):
            raise ValueError('Positive QoS weights required for P/E/GPU/NPU')
        if self.fixed_latency_cycles < 0 or self.gpu_codec_cycles < 0:
            raise ValueError('Nonnegative latency required')

    @property
    def peak_gbs(self):
        return self.mtps * self.width_bits / 8000

    @property
    def sustained_gbs(self):
        return self.peak_gbs * self.efficiency

    @property
    def channel_bytes_per_cycle(self):
        return self.sustained_gbs * 1e9 / CLOCK_HZ / self.channels


def quad_ddr5_6400():
    return MemoryConfig('Quad DDR5-6400 (4x64-bit)', 6400, 256, 4)


def lpddr5x_8533(compression=.5):
    return MemoryConfig('LPDDR5X-8533 (8x32-bit; 256-bit custom)', 8533, 256, 8,
                        gpu_compress_fraction=compression)


@dataclass
class MemoryJob:
    req_id: int
    owner: str
    line: int
    arrived: int
    physical_bytes: int
    logical_bytes: int = 64
    compressed: bool = False


class WeightedMemoryController:
    """Per-channel shared work-conserving byte-fair NoC-to-DRAM queue.

    E gets >= its configured long-run service weight while every class is
    continuously backlogged with balanced channels; finite-trace bounds are not
    strict guaranteed QoS, and DDR bank/turnaround penalties aren't modeled.
    """
    def __init__(self, cfg: MemoryConfig):
        self.cfg=cfg
        self.queues=[{c:deque() for c in ORDER} for _ in range(cfg.channels)]
        self.virtual_finish=[{c:0. for c in ORDER} for _ in range(cfg.channels)]
        self.credit=[0. for _ in range(cfg.channels)]
        self.active=[None for _ in range(cfg.channels)]
        self.active_remaining=[0. for _ in range(cfg.channels)]
        self.stats=Counter()
        self.latencies={c:[] for c in ORDER}
        self.peak_backlog=0
        self.queue_area=0
        self.busy_channel_cycles=0

    def channel_for(self,line:int)->int:
        return (line ^ (line>>7) ^ (line>>13)) & (self.cfg.channels - 1)

    def submit(self,req_id:int,owner:str,line:int,now:int,logical_bytes=64):
        if owner not in ORDER or logical_bytes <= 0:
            raise ValueError('Invalid owner or bytes')
        # Synthetic compressibility: deterministic per line, no real texture/depth codec.
        sample=((line*0x9e3779b1) ^ (line>>3)) & 0xffff
        compress=(owner=='GPU' and sample/65536 < self.cfg.gpu_compress_fraction)
        physical_bytes=max(1,round(logical_bytes*(self.cfg.gpu_compression_ratio if compress else 1)))
        job=MemoryJob(req_id,owner,line,now,physical_bytes,logical_bytes,compress)
        c=self.channel_for(line)
        self.queues[c][owner].append(job)
        self.stats['issued_'+owner]+=1
        self.stats['logical_bytes_'+owner]+=logical_bytes
        self.stats['physical_bytes_'+owner]+=physical_bytes
        if compress:self.stats['compressed_gpu_requests']+=1

    def _select(self,chan:int):
        q=self.queues[chan]
        ready=[c for c in ORDER if q[c]]
        if not ready:return None
        # Weighted fair scheduling with a per-channel virtual service timeline.
        # Restore idle flows to active virtual-time floor so they do not carry
        # arbitrarily large unused service credit across long idle intervals.
        floor=min(self.virtual_finish[chan][c] for c in ready)
        for c in ready:
            if self.virtual_finish[chan][c] < floor:
                self.virtual_finish[chan][c]=floor
        winner=min(ready,key=lambda c:(self.virtual_finish[chan][c],ORDER.index(c)))
        job=q[winner].popleft()
        self.virtual_finish[chan][winner]=max(self.virtual_finish[chan][winner],floor)+job.physical_bytes/self.cfg.qos_weights[winner]
        return job

    def tick(self,now:int):
        """Returns (ready_cycle, req_id) on physical transfer completion."""
        finished=[]
        rate=self.cfg.channel_bytes_per_cycle
        backlog=sum(sum(len(q) for q in channel.values()) for channel in self.queues)
        backlog+=sum(job is not None for job in self.active)
        self.peak_backlog=max(self.peak_backlog,backlog)
        self.queue_area+=backlog
        for i in range(self.cfg.channels):
            if self.active[i] is None and not any(self.queues[i][c] for c in ORDER):
                self.credit[i]=0  # do not save idle capacity for future bursts
                continue
            self.busy_channel_cycles+=1
            self.credit[i] += rate
            while True:
                if self.active[i] is None:
                    job=self._select(i)
                    if job is None:
                        self.credit[i]=0
                        break
                    self.active[i]=job
                    self.active_remaining[i]=float(job.physical_bytes)
                n=min(self.credit[i],self.active_remaining[i])
                self.credit[i]-=n
                self.active_remaining[i]-=n
                if self.active_remaining[i] > 1e-8:
                    break
                job=self.active[i]
                self.active[i]=None
                self.stats['completed_'+job.owner]+=1
                self.latencies[job.owner].append(now-job.arrived+1)
                codec=self.cfg.gpu_codec_cycles if job.compressed else 0
                finished.append((now+self.cfg.fixed_latency_cycles+codec+1,job.req_id))
        return finished

    def pending(self):
        return any(self.active) or any(q for channel in self.queues for q in channel.values())

    def snapshot(self,cycles:int):
        cycles=max(1,cycles)
        logical=sum(self.stats['logical_bytes_'+c] for c in ORDER)
        physical=sum(self.stats['physical_bytes_'+c] for c in ORDER)
        done=sum(self.stats['completed_'+c] for c in ORDER)
        return dict(config=self.cfg.name,peak_gbs=round(self.cfg.peak_gbs,3),
                    sustained_gbs=round(self.cfg.sustained_gbs,3),
                    nominal_channels=self.cfg.channels,
                    transferred_logical_bytes=logical,transferred_physical_bytes=physical,
                    theoretical_compression_saved_pct=round(100*(1-physical/max(1,logical)),3),
                    peak_pending_requests=self.peak_backlog,
                    mean_pending_requests=round(self.queue_area/cycles,2),
                    controller_mean_transfer_cycles={k:round(sum(v)/len(v),2) if v else None for k,v in self.latencies.items()},
                    completed_memory_jobs=done,
                    class_service_counts={k:self.stats['completed_'+k] for k in ORDER},
                    fraction_channels_busy=round(self.busy_channel_cycles/(cycles*self.cfg.channels),4),
                    compressed_gpu_requests=self.stats['compressed_gpu_requests'])
