"""Static acyclicity check of *escape-only* deterministic XY routes on 4x7 mesh.

Proves: under assumed wormhole single-vnet escape routing, channel dependency
edges formed by XY routes have no cycles. DOES NOT prove deadlock freedom of
adaptive VCs, coherence-message dependencies, TSV crossings or physical RTL.
"""
from __future__ import annotations
import argparse
import json
from collections import defaultdict, deque


def xy_path(s: int, d: int, rows: int, cols: int) -> list[int]:
    x, y = s % cols, s // cols
    tx, ty = d % cols, d // cols
    path = [s]
    while x != tx:
        x += 1 if tx > x else -1
        path.append(y * cols + x)
    while y != ty:
        y += 1 if ty > y else -1
        path.append(y * cols + x)
    return path


def is_acyclic(graph: dict) -> bool:
    indeg = {u: 0 for u in graph}
    for u, children in graph.items():
        for v in children:
            indeg.setdefault(v, 0)
            indeg[v] += 1
    todo = deque(u for u, degree in indeg.items() if degree == 0)
    seen = 0
    while todo:
        u = todo.popleft()
        seen += 1
        for v in graph.get(u, ()):
            indeg[v] -= 1
            if indeg[v] == 0:
                todo.append(v)
    return seen == len(indeg)


def check_escape(rows: int = 4, cols: int = 7) -> dict:
    if rows < 2 or cols < 2:
        raise ValueError("mesh needs at least 2x2")
    graph = defaultdict(set)
    count = 0
    for s in range(rows * cols):
        for d in range(rows * cols):
            if s == d:
                continue
            nodes = xy_path(s, d, rows, cols)
            channels = list(zip(nodes, nodes[1:]))
            for c in channels:
                graph[c]  # a channel with no outgoing dep still exists
            for a, b in zip(channels, channels[1:]):
                graph[a].add(b)
                count += 1
    return {"rows": rows, "cols": cols, "routers": rows * cols,
            "escape_policy": "deterministic_X_before_Y_no_escape_to_adaptive",
            "escape_channel_count": len(graph), "dependency_edges_observed": count,
            "escape_only_dependency_graph_acyclic": is_acyclic(graph),
            "scope": "escape-only XY 2D mesh; excludes TSV, protocol vnets and adaptive VC proof"}


def cli():
    p = argparse.ArgumentParser()
    p.add_argument("--rows", type=int, default=4)
    p.add_argument("--cols", type=int, default=7)
    args = p.parse_args()
    print(json.dumps(check_escape(args.rows, args.cols), indent=2))


if __name__ == "__main__":
    cli()
