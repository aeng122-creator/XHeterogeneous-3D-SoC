"""Reject fabricated foundry-calibration claims; validate supplied PDK metadata.

A passed config validation != a validated chip or signoff. A public value for
voltage and a 'node' name are insufficient.
"""
from __future__ import annotations
import json
from pathlib import Path

REQUIRED = (
    "pdk_license_available", "standard_cell_library", "memory_macro_models",
    "voltage_frequency_tables", "leakage_vs_temperature", "interconnect_rc",
    "thermal_material_stack", "floorplan_with_dimensions", "power_activity_traces"
)


def validate(path: str | Path) -> dict:
    metadata = json.loads(Path(path).read_text(encoding="utf-8"))
    missing = [k for k in REQUIRED if not metadata.get(k)]
    if not missing:
        status = "READY_FOR_FOUNDARY_CALIBRATION_REVIEW"
    else:
        status = "CALIBRATION_BLOCKED"
    return {"status": status, "missing": missing,
            "notice": "No tool-based architecture power estimate establishes physical sign-off."}


if __name__ == "__main__":
    import argparse
    a = argparse.ArgumentParser()
    a.add_argument("metadata", type=Path)
    args = a.parse_args()
    print(json.dumps(validate(args.metadata), indent=2))
