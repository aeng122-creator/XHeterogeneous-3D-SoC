"""V3.4 Arc-class iGPU proxy power, 170/180/120 W controller tests."""
from __future__ import annotations
import argparse,json,csv
from pathlib import Path
from sim.power_controller import PowerController,ProtectionConfig

# Illustrative per-domain watt demands, not RTL-derived power estimates.
PROFILES={
 'idle': ({'P':2.0,'E':1.6,'GPU':.7,'NPU':.3},6.0),
 'moderate': ({'P':40.0,'E':28.8,'GPU':25.0,'NPU':7.0},31.509),
 'extreme': ({'P':56.0,'E':48.0,'GPU':30.0,'NPU':10.0},41.509),
 'fault': ({'P':56.0,'E':48.0,'GPU':30.0,'NPU':10.0},41.509),
}

def run_scenario(profile: str, seconds:float=6.0, dt:float=.001,
                 ambient:float=25.0, failed_sensor_at:float|None=None):
    cfg=ProtectionConfig(dt_s=dt,ambient_c=ambient)
    ctrl=PowerController(cfg)
    # Simulated starting temperature equals selected ambient.
    trace=[]
    demand,uncore=PROFILES[profile]
    steps=round(seconds/dt)
    for i in range(steps):
        t=i*dt
        bad=failed_sensor_at is not None and t>=failed_sensor_at
        row=ctrl.step(demand,uncore,sensor_ok=not bad,sensor_age_s=.1 if bad else 0)
        if i==0 or i==steps-1 or i%max(1,int(.1/dt))==0 or row['events'] and any('TRIP' in e for e in row['events']):
            trace.append(row)
    s=ctrl.state
    return {
        'profile':profile,'seconds':seconds,'ambient_c':ambient,
        'nominal_requested_w':round(uncore+sum(demand.values()),3),
        'max_applied_w':round(max(r['applied_power_w'] for r in trace),3),
        'mean_applied_w':round(s.total_energy_j/s.time_s,3),
        'final_clock_scales':trace[-1]['clocks'],
        'last_mode':trace[-1]['mode'],
        'final_tier_temps_c':[trace[-1]['tier1_c'],trace[-1]['tier2_c']],
        'prevention_count':s.preventive_events,
        'clamp_count':s.clamp_events,
        'sensor_fault_count':s.sensor_fault_events,
        'trip_count':s.trip_events,
        'boost_exhausted_steps':s.sustained_events,
        'last_boost_credit_j':trace[-1]['boost_credit_j'],
        'trace_100ms':trace,
        'limitations':'Synthetic per-domain watt demands, instantaneous ideal clamp and coarse two-node RC. Not gem5/RTL/SPICE/CFD or measured hardware.',
    }

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out',default='results/v3_3_power_protection.json')
    args=p.parse_args()
    experiments={
        'idle':run_scenario('idle',5),
        'moderate':run_scenario('moderate',8),
        'extreme':run_scenario('extreme',8),
        'extreme_hot_ambient':run_scenario('extreme',8,ambient=35),
        'sensor_failure':run_scenario('fault',3,failed_sensor_at=1),
    }
    dest=Path(args.out);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps({'config':ProtectionConfig().__dict__,'experiments':experiments},indent=2),encoding='utf-8')
    for name,r in experiments.items():
        print(f"{name:22} request={r['nominal_requested_w']:7.2f} W | peak applied={r['max_applied_w']:7.2f} W | mean={r['mean_applied_w']:7.2f} W | mode={r['last_mode']:9} | temps={r['final_tier_temps_c']}")
    print(f'Written {dest}')
if __name__=='__main__':main()
