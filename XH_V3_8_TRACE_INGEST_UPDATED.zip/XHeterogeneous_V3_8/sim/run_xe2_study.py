"""V3.4 experimental study; model results are synthetic and not Intel measurements."""
import json, argparse
from pathlib import Path
from .model import run_modes
from .run_power_protection import run_scenario,PROFILES
from .xe2_gpu import Arc140VProxy

def study(network_cycles=750,network_intensity=1.5):
    gpu=Arc140VProxy()
    power={name:run_scenario(name,seconds=5) for name in ['idle','moderate','extreme']}
    return {
      'model':'V3.4 Xe2-like iGPU + CPU/E + shared-DDR memory traffic and separate DVFS+thermal model',
      'sources':{
       'Intel_reference':'https://www.intel.com/content/www/us/en/products/sku/240957/intel-core-ultra-7-processor-258v-12m-cache-up-to-4-80-ghz/specifications.html',
       'Intel_architecture':'https://www.intel.com/content/www/us/en/docs/oneapi/optimization-guide-gpu/2025-2/intel-xe-gpu-architecture.html'},
      'power_profiles':{name:{'requested_gpu_w':PROFILES[name][0]['GPU'],
                     **{k:v for k,v in run.items() if k!='trace_100ms'}} for name,run in power.items()},
      'network':{'cycles':network_cycles,'intensity':network_intensity,
                 'results':run_modes(network_cycles,117,network_intensity,85000)},
      'gpu_theoretical_roofline':{
        'light_8k':gpu.roofline(flops_per_pixel=1000,external_bytes_per_pixel=32),
        'heavy_8k':gpu.roofline(flops_per_pixel=20000,external_bytes_per_pixel=128),
        'heavy_8k_30pct_memory_share':gpu.roofline(flops_per_pixel=20000,external_bytes_per_pixel=128,ddr_gpu_share=.3)
      },
      'limitations':['No GPU shader/RT/raster execution; IPC not simulated',
                     'No calibrated power vs voltage/frequency curve; 30W GPU assumed',
                     'No real 8K rendering measured','Shared DDR proxy is ONE serialized queue',
                     'Protective controller not connected to packet timing; independent analytic experiments']}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--cycles',type=int,default=750)
    ap.add_argument('--intensity',type=float,default=1.5)
    ap.add_argument('--out',default='results/v3_4_arc140v_study.json')
    a=ap.parse_args()
    result=study(a.cycles,a.intensity)
    out=Path(a.out);out.parent.mkdir(exist_ok=True,parents=True)
    out.write_text(json.dumps(result,indent=2,ensure_ascii=False))
    print('Wrote',out)
    for tag,row in result['network']['results'].items():
        print(tag,'GPU P95',row['GPU']['p95_cycles'],'P P95',row['CPU_P']['p95_cycles'],'DDR MB',row['mem_DDR_MB'],'NoC W',row['noc_power_proxy_W'])
    for tag,row in result['power_profiles'].items():
        print(tag,'raw W',row['nominal_requested_w'],'applied peak W',row['max_applied_w'],'mean W',row['mean_applied_w'],'final mode',row['last_mode'])

if __name__=='__main__':main()
