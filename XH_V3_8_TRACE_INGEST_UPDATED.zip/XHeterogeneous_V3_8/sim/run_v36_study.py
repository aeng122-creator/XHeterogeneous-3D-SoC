"""Run V3.6 controlled stress, vertical gateway and thermal RC sensitivity."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from .v36_prototype import HybridConfig,HybridMemory,make_stress_trace,VerticalNetwork,ThermalRC,load_thermal,simulate_policy_thermal
from .power_controller import PowerController,ProtectionConfig
from .run_power_protection import PROFILES


def study(cycles=12_000):
    demand=263.62
    mem={}
    for hit in (0.0,.25,.45,.50,.55,.70):
        cfg=HybridConfig(hbm_hit_fraction=hit)
        trace=make_stress_trace(cycles=cycles,demand_gbs=demand,hbm_hit_fraction=hit)
        mem[f'hbm_hit_target_{int(hit*100)}pct']=HybridMemory(cfg).simulate(trace)
    lp_baseline_cfg=HybridConfig(ddr_channels=8,ddr_mtps=8533,hbm_hit_fraction=0.0)
    lp_baseline=HybridMemory(lp_baseline_cfg).simulate(
        make_stress_trace(cycles=cycles,demand_gbs=demand,hbm_hit_fraction=0.0))
    no_comp=HybridConfig(compression=False)
    comp=HybridConfig(compression=True)
    trace=make_stress_trace(cycles=cycles,demand_gbs=demand,hbm_hit_fraction=.55)
    no_comp_r=HybridMemory(no_comp).simulate(trace)
    comp_r=HybridMemory(comp).simulate(trace)
    # Explicit cyclic mixed request stimulus. Two packets/cycle yield pressure on
    # a single central gateway; four independent gateways reduce queueing.
    arrivals=[t for t in range(3000) for _ in range(2)]
    vnet=VerticalNetwork(ports=4)
    vertical={'single_central_gateway':vnet.run(arrivals,adaptive=False),
              'four_distributed_gateways':vnet.run(arrivals,adaptive=True),
              'upper_tier_gpu_l3_local':vnet.run(arrivals,local_gpu=True)}
    thermal=ThermalRC(load_thermal())
    # Hypothetical package power split, HBM included in total.
    power180={'bottom_cpu_tier':108.0,'top_gpu_l3_tier':60.0,'adjacent_hbm3_stack':12.0,'stepped_copper_plate':0.0}
    power120={'bottom_cpu_tier':72.0,'top_gpu_l3_tier':40.0,'adjacent_hbm3_stack':8.0,'stepped_copper_plate':0.0}
    thermal_out={'policy_2s_180W_then_120W':simulate_policy_thermal(thermal,power180,power120),
                 'hypothetical_fixed_180W_120s_NOT_ALLOWED_BY_POWER_POLICY':thermal.simulate(power180),
                 'sustained_120W_120s_illustrative':thermal.simulate(power120)}
    # Existing V3.3 protective cap, with assumed extra 14W HBM+interface power
    pwr=PowerController(ProtectionConfig())
    requested_domains,old_uncore=PROFILES['extreme']
    protected=[]
    for t in range(5000):
        tick=pwr.step(requested_domains,old_uncore+14.0)
        if t in (0,1999,4999):
            protected.append(tick)
    result={
        'status':'Controlled synthetic cache-hit stimulus; byte-credit memory queues; simple TSV gateway and RC solver. No calibrated silicon/3D ICE/gem5.',
        'hardware_constraints':{'cpu_cores':40,'cpu_threads':48,'silicon_tiers':2,'l1_mib':3,'l2_mib':48,'l3_mib':112,
                                'cpu_l3_mib':96,'gpu_l3_mib':16,
                                'quad_ddr5_peak_gbs':204.8,'quad_ddr5_sustained_assumed_gbs':153.6,
                                'hbm3_per_stack_peak_gbs':819.2,'hbm3_per_stack_sustained_assumed_gbs':573.44,
                                'hbmcaching_mode':'memory-side L4 cache of DDR5, not replacement for SRAM L3',
                                'gpu_upper_tier_to_l3':'local upper-tier dedicated link; NO TSV needed for same-tier exchange',
                                'cross_tier_cpu_l3':'multiple TSV gateway ports; deterministic escape VC needs gem5/RTL proof'},
        'v35_lpddr5x_no_hbm_baseline_same_trace':lp_baseline,
        'memory_hit_sensitivity':mem,
        'compression_comparison':{'uncompressed':no_comp_r,'adaptive_bypass':comp_r},
        'vertical_path_test':vertical,
        'thermal':thermal_out,
        'power_controller_stress_with_HBM':{'nominal_requested_W':round(sum(requested_domains.values())+old_uncore+14.,3),'trace':protected,'notice':'Simulated old software clamp, not physical silicon or coupled into new thermal RC.'},
        'power_warnings':{'boost_w':180,'sustained_w':120,'trigger_w':170,
                          'additional_hbm_pkg_w_example':12,
                          'old_uncalibrated_extreme_demand_w':185.51,
                          'new_package_demand_before_dvfs_w_if_hbm_adds_12W_and_control_2W':199.51,
                          'pkg_limit_includes_hbm':'yes'},
        'not_implemented':['Actual TSV timing and link transistor models',
                           'Real HBM hit rate derived from a workload footprint and realistic capacity',
                           'Full inclusive/non-inclusive directory and memory consistency RTL',
                           'Deadlock proof for escape virtual channels',
                           'JEDEC command timing, refresh and HBM topology',
                           'gem5/GPGPU-Sim joint cycle accurate execution',
                           '3D-ICE thermal floorplan calibration']}
    return result


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--cycles',type=int,default=12000)
    ap.add_argument('--out',default='results/v3_6_study.json')
    args=ap.parse_args()
    d=study(cycles=args.cycles)
    dest=Path(args.out)
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding='utf8')
    print('V3.6 controlled sensitivity study, cycles=',args.cycles)
    for k,v in d['memory_hit_sensitivity'].items():
        print(f'{k:<23} hits={v["hbm_hit_fraction_observed"]:.3f} '
              f'DDR_peak={v["ddr_peak_backlog"]:5} GPU_P95={v["P95_response_cycles"]["GPU"]:6} '
              f'ExtraDrain={v["drain_extension_cycles"]:5}')
    for k,v in d['vertical_path_test'].items():print(k,v['p95_cycles'],v['p99_cycles'])
    print('wrote',dest)
if __name__=='__main__':main()
