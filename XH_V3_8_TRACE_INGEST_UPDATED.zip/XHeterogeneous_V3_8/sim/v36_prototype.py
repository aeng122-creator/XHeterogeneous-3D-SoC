"""V3.6 two-tier memory/interconnect/thermal *proxy*.

Cycle-stepped bandwidth and queues; NOT JEDEC timing, RTL, silicon/CFD, or
full cache-coherence verification. Controlled HBM hit stimulus is a sensitivity
input, not a prediction of an actual HBM cache's hit rate.
"""
from __future__ import annotations
from collections import defaultdict, deque, Counter
from dataclasses import dataclass, field
from heapq import heappush, heappop
import json
import math
import random
from pathlib import Path

CLOCK=2.5e9
ORDER=('P','E','GPU','NPU')
WEIGHTS={'P':0.3,'E':0.125,'GPU':0.5,'NPU':0.075}

@dataclass(frozen=True)
class HybridConfig:
    ddr_channels:int=4
    ddr_bits:int=256
    ddr_mtps:int=6400
    ddr_eff:float=.75
    hbm_channels:int=16
    hbm_bits:int=1024
    hbm_mtps:int=6400
    hbm_eff:float=.70
    # Synthetic latency assumptions in CPU 2.5GHz cycles, not from vendor timing
    ddr_latency:int=95
    hbm_latency:int=65
    hbm_hit_fraction:float=.55
    compression:bool=True
    codec_cycles:int=14
    gpu_comp_fraction:float=.45
    comp_ratio:float=.5

    @property
    def ddr_sustained_gbs(self):return self.ddr_bits*self.ddr_mtps/8000*self.ddr_eff
    @property
    def hbm_sustained_gbs(self):return self.hbm_bits*self.hbm_mtps/8000*self.hbm_eff

@dataclass
class Transfer:
    req:int
    owner:str
    arrival:int
    size:int
    fill:bool=False

class ByteCreditBus:
    """Per-channel byte-credit scheduler, WFQ-like arbitration on packet starts.

    This is NOT a strict end-to-end QoS guarantee or an accurate DDR command model.
    """
    def __init__(self,channels,rate_gbs):
        self.channels=channels
        self.rate=rate_gbs*1e9/CLOCK/channels
        self.pending=[{key:deque() for key in ORDER} for _ in range(channels)]
        self.virtual=[{key:0.0 for key in ORDER} for _ in range(channels)]
        self.credit=[0.0]*channels
        self.active=[None]*channels
        self.remaining=[0.0]*channels
        self.bytes=Counter()
        self.peak=0
        self.pending_at_end=0
    def submit(self,tx:Transfer,key:int):
        ch=(key^(key>>9)^(key>>17))&(self.channels-1)
        self.pending[ch][tx.owner].append(tx)
    def _select(self,i):
        queued=[c for c in ORDER if self.pending[i][c]]
        if not queued:return None
        f=min(self.virtual[i][c] for c in queued)
        for c in queued:self.virtual[i][c]=max(self.virtual[i][c],f)
        c=min(queued,key=lambda k:(self.virtual[i][k],ORDER.index(k)))
        tx=self.pending[i][c].popleft()
        self.virtual[i][c]+=tx.size/WEIGHTS[c]
        return tx
    def tick(self):
        returned=[]
        self.peak=max(self.peak,self.backlog())
        for i in range(self.channels):
            if self.active[i] is None and not any(self.pending[i][c] for c in ORDER):
                self.credit[i]=0.0
                continue
            self.credit[i]+=self.rate
            while True:
                if self.active[i] is None:
                    tx=self._select(i)
                    if tx is None:
                        self.credit[i]=0.
                        break
                    self.active[i]=tx
                    self.remaining[i]=float(tx.size)
                consumed=min(self.remaining[i],self.credit[i])
                self.credit[i]-=consumed
                self.remaining[i]-=consumed
                if self.remaining[i]>1e-8:break
                tx=self.active[i]
                self.active[i]=None
                self.bytes['total']+=tx.size
                self.bytes[tx.owner]+=tx.size
                if tx.fill:self.bytes['fills']+=tx.size
                returned.append(tx)
        return returned
    def backlog(self):
        return sum(sum(len(q) for q in ch.values()) for ch in self.pending)+sum(a is not None for a in self.active)

class AdaptiveCompression:
    """Classifier is explicitly given entropy by synthetic stimulus.
    Compresses low entropy lines only. Compression ratio and codec cost assumed.
    """
    def __init__(self,enabled=True,codec_cycles=14,ratio=.5):
        self.enabled=enabled
        self.codec_cycles=codec_cycles
        self.ratio=ratio
        self.count=Counter()
    def evaluate(self,owner,entropy,logical_bytes=64):
        low=entropy in ('zero','repeated')
        compress=self.enabled and owner=='GPU' and low
        self.count['requests']+=1
        if owner=='GPU':
            self.count['gpu']+=1
            if not low:self.count['gpu_bypass_entropy']+=1
        if compress:self.count['compressed']+=1
        n=round(logical_bytes*(self.ratio if compress else 1))
        return n,(self.codec_cycles if compress else 0)

class HybridMemory:
    def __init__(self,cfg:HybridConfig):
        self.cfg=cfg
        self.ddr=ByteCreditBus(cfg.ddr_channels,cfg.ddr_sustained_gbs)
        self.hbm=ByteCreditBus(cfg.hbm_channels,cfg.hbm_sustained_gbs)
        self.codec=AdaptiveCompression(cfg.compression,cfg.codec_cycles,cfg.comp_ratio)
        self.events=[]
        self.pending_count=0
        self.latencies=defaultdict(list)
        self.traffic=Counter()
        self.maximum_backlog=0
        self.total=0
        self.completed=0
        self.max_cycle=0

    def simulate(self,trace,max_drain=180000):
        # trace contains (cycle, request ID, class, line, entropy, bool hbm_hit)
        schedule=defaultdict(list)
        request={}
        for t,rid,owner,line,entropy,hit in trace:
            schedule[t].append((rid,owner,line,entropy,hit))
            request[rid]=(t,owner,line,entropy,hit)
        end_injection=max((row[0] for row in trace),default=0)
        for t in range(end_injection+max_drain+1):
            for rid,owner,line,entropy,hit in schedule.get(t,[]):
                n,penalty=self.codec.evaluate(owner,entropy)
                self.traffic['demand_logical_bytes']+=64
                self.traffic['request_physical_bytes']+=n
                self.total+=1
                if hit:
                    self.traffic['hbm_hits']+=1
                    self.hbm.submit(Transfer(rid,owner,t,n),line)
                else:
                    self.traffic['hbm_misses']+=1
                    self.ddr.submit(Transfer(rid,owner,t,n),line)
            for tx in self.ddr.tick():
                _,_,line,entropy,_=request[tx.req]
                heappush(self.events,(t+self.cfg.ddr_latency,tx.req))
                # A missed read also allocates a clean line in HBM in this model.
                self.hbm.submit(Transfer(tx.req,tx.owner,t,tx.size,fill=True),line)
            for tx in self.hbm.tick():
                if not tx.fill:heappush(self.events,(t+self.cfg.hbm_latency,tx.req))
            while self.events and self.events[0][0]<=t:
                _,rid=heappop(self.events)
                injection,owner,line,entropy,hit=request[rid]
                penalty=self.cfg.codec_cycles if self.cfg.compression and owner=='GPU' and entropy in ('zero','repeated') else 0
                self.latencies[owner].append(t-injection+penalty)
                self.completed+=1
            self.maximum_backlog=max(self.maximum_backlog,self.ddr.backlog()+self.hbm.backlog())
            if self.completed==self.total and self.total and t>=end_injection and self.ddr.backlog()==0 and self.hbm.backlog()==0:
                self.max_cycle=t
                break
        else:raise RuntimeError('Queue failed to drain within limit')
        def pc(v,p):
            return sorted(v)[math.floor((len(v)-1)*p)] if v else None
        duration=max(1,end_injection+1)
        return {'issued':self.total,'completed':self.completed,
                'injection_cycles':duration,'drained_cycle':self.max_cycle,
                'drain_extension_cycles':max(0,self.max_cycle-end_injection),
                'demand_gbs':round(self.traffic['demand_logical_bytes']*CLOCK/1e9/duration,2),
                'demand_physical_gbs':round(self.traffic['request_physical_bytes']*CLOCK/1e9/duration,2),
                'hbm_hits':self.traffic['hbm_hits'],
                'hbm_hit_fraction_observed':round(self.traffic['hbm_hits']/max(1,self.total),4),
                'ddr_read_gbs_during_injection':round((self.ddr.bytes['total']-self.ddr.bytes['fills'])*CLOCK/1e9/duration,2),
                'ddr_total_bytes':self.ddr.bytes['total'],
                'hbm_total_bytes':self.hbm.bytes['total'],
                'hbm_fill_bytes':self.hbm.bytes['fills'],
                'ddr_peak_backlog':self.ddr.peak,
                'hbm_peak_backlog':self.hbm.peak,
                'peak_combined_backlog':self.maximum_backlog,
                'codec':dict(self.codec.count),
                'P95_response_cycles':{c:pc(self.latencies[c],.95) for c in ORDER},
                'P99_response_cycles':{c:pc(self.latencies[c],.99) for c in ORDER}}


def make_stress_trace(cycles=12000,demand_gbs=263.62,hbm_hit_fraction=.55,
                      gpu_compress_fraction=.45,seed=27):
    """Controlled-HBM-hit sensitivity trace; no claims about real hit prediction."""
    rng=random.Random(seed)
    probs=[('P',.22),('E',.28),('GPU',.45),('NPU',.05)]
    acc=0.
    out=[];rid=0
    per_cycle=demand_gbs*1e9/CLOCK/64
    for t in range(cycles):
        acc+=per_cycle
        while acc>=1-1e-12:
            acc-=1
            x=rng.random()
            owner=next((c for c,p in probs if x < sum(q for _,q in probs[:probs.index((c,p))+1])), 'NPU')
            low=(owner=='GPU' and rng.random()<gpu_compress_fraction)
            entropy='repeated' if low else 'random'
            hit=rng.random()<hbm_hit_fraction
            # Mixed, seeded line addresses, cycling an offset plus source id to distribute channels.
            line=((rid*0x9e3779b1)^(rid>>7))&0xffffffff
            out.append((t,rid,owner,line,entropy,hit))
            rid+=1
    return out

class VerticalNetwork:
    """Simplified per-gateway FIFO for cross-tier request packets, not a flit-level router.

    GPU->upper-tier L3 local access does NOT use a TSV; CPU cross-tier does.
    Escape traffic uses adaptive alternate gateways, with reserved deterministic
    XY fallback VC in the target RTL; deadlock freedom requires later proof.
    """
    def __init__(self,ports=4,service_per_cycle=1):
        self.ports=ports
        self.service=service_per_cycle
    def run(self,arrival_cycles,adaptive=True,local_gpu=False):
        free=[0]*self.ports;lat=[];usage=Counter();routes=[]
        for i,t in enumerate(arrival_cycles):
            if local_gpu:lat.append(2);routes.append(-1);continue
            # adaptive model chooses less busy vertical gateway.
            options=range(self.ports) if adaptive else (0,)
            port=min(options,key=lambda p:(max(t,free[p])-t,p))
            completion=max(t,free[port])+1
            free[port]=completion
            lat.append(completion-t)
            usage[port]+=1
            routes.append(port)
        y=sorted(lat)
        return {'p95_cycles':y[int(.95*(len(y)-1))] if y else None,
                'p99_cycles':y[int(.99*(len(y)-1))] if y else None,
                'max_cycles':max(y) if y else None,
                'per_gateway_packets':{str(i):usage[i] for i in range(self.ports)},
                'bypassed_tsv_for_upper_gpu_l3':local_gpu}

class ThermalRC:
    """Lumped RC 4-node solver: two silicon tiers, side HBM stack, copper plate.
    It is NOT a 3D-ICE or CFD solve and does not model geometry/local hot spots.
    """
    def __init__(self,config):
        self.cfg=config
        self.nodes=config['nodes']
        self.edges=config['resistances_K_per_W']
        self.coolant=config['coolant_C']
    def simulate(self,power_by_node,seconds=120.,dt=.01):
        temp={name:self.coolant for name in self.nodes}
        summary=[]
        for i in range(int(seconds/dt)):
            next_temp={}
            for name,node in self.nodes.items():
                flux=power_by_node.get(name,0.)
                for edge in self.edges:
                    if edge['a']==name:
                        target=self.coolant if edge['b']=='coolant' else temp[edge['b']]
                        flux+=(target-temp[name])/edge['R']
                    elif edge['b']==name:
                        target=self.coolant if edge['a']=='coolant' else temp[edge['a']]
                        flux+=(target-temp[name])/edge['R']
                next_temp[name]=temp[name]+dt*flux/node['C_J_per_K']
            temp=next_temp
            if i in (int(2/dt)-1,int(20/dt)-1,int(seconds/dt)-1):
                summary.append({'seconds':round((i+1)*dt,2),
                                'nodes_C':{k:round(v,2) for k,v in temp.items()}})
        return summary


def load_thermal(path=None):
    path=Path(path) if path else Path(__file__).resolve().parents[1]/'config'/'thermal_rc.json'
    return json.loads(path.read_text(encoding='utf8'))

class IsolatedL3:
    """GPU 16MiB and CPU 96MiB non-overlapping physical data allocation.

    This models capacity and namespace protection only, NOT cache coherence.
    Scaled-down capacity option exists solely for fast tests.
    """
    def __init__(self,scale=256):
        from collections import OrderedDict
        self.cache={'CPU':OrderedDict(),'GPU':OrderedDict()}
        self.max_lines={'CPU':(96*1024*1024//scale)//64,
                        'GPU':(16*1024*1024//scale)//64}
        self.evictions=Counter()
    def access(self,owner,line,insert=True):
        if owner not in self.cache:raise ValueError('CPU or GPU required')
        data=self.cache[owner]
        if line in data:
            data.move_to_end(line)
            return True
        if insert:
            data[line]=None
            while len(data)>self.max_lines[owner]:
                data.popitem(last=False)
                self.evictions[owner]+=1
        return False
    def size(self,owner):return len(self.cache[owner])

class EscapeRoutingPolicy:
    """Adaptive peripheral detours with a separate deterministic XY escape VC.

    Per-packet cycle-free paths are checked, BUT the full system-level VC
    channel dependency graph / protocol deadlock freedom is NOT proven here.
    Never reenter adaptive VC after switching to escape_xy VC.
    """
    def __init__(self,rows=4,cols=7):
        self.rows=rows
        self.cols=cols
    def xy(self,start,end):
        x,y=start;ex,ey=end
        out=[start]
        while x!=ex:
            x+=1 if ex>x else -1;out.append((x,y))
        while y!=ey:
            y+=1 if ey>y else -1;out.append((x,y))
        return out
    def _via(self,start,end,waypoint):
        a=self.xy(start,waypoint);b=self.xy(waypoint,end)
        path=a+b[1:]
        return path if len(set(path))==len(path) else None
    def choose(self,start,end,edge_backlog,weight=2.0):
        primary=self.xy(start,end)
        options=[('xy',primary)]
        for row in (0,self.rows-1):
            for col in (0,self.cols-1):
                p=self._via(start,end,(col,row))
                if p and p!=primary:options.append(('perimeter',p))
        def score(path):
            return len(path)-1+weight*sum(edge_backlog.get((u,v),0) for u,v in zip(path,path[1:]))
        label,path=min(options,key=lambda v:(score(v[1]),len(v[1]),v[0]))
        return {'selected':label,'vc':'adaptive' if label!='xy' else 'escape_xy',
                'path':path,'escape_vc':'escape_xy','escape_path':primary,
                'must_remain_escape_after_fallback':True}

def simulate_policy_thermal(thermal:ThermalRC, boost_power, sustained_power,
                            boost_seconds=2.,seconds=120.,dt=.01):
    """Lumped RC under a simplified 2-second 180W boost then 120W continuous policy."""
    temp={k:thermal.coolant for k in thermal.nodes}
    out=[]
    milestones=(2.,20.,120.)
    for i in range(int(seconds/dt)):
        t=(i+1)*dt
        selected=boost_power if t<=boost_seconds+1e-9 else sustained_power
        next_temp={}
        for name,node in thermal.nodes.items():
            flux=selected.get(name,0.)
            for e in thermal.edges:
                if e['a']==name or e['b']==name:
                    dest=e['b'] if e['a']==name else e['a']
                    other=thermal.coolant if dest=='coolant' else temp[dest]
                    flux+=(other-temp[name])/e['R']
            next_temp[name]=temp[name]+dt*flux/node['C_J_per_K']
        temp=next_temp
        if any(abs(t-m)<=dt*.5 for m in milestones):
            out.append({'time_s':round(t,2),'mode':'boost' if t<=boost_seconds+1e-9 else 'sustained',
                        'nodes_C':{k:round(v,2) for k,v in temp.items()}})
    return out
