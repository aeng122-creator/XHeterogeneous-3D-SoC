"""Read a normalized *read-only* trace into the legacy V3.7 NoC timing proxy.

This is for integration experiments, NOT cycle-accurate instruction execution.
'order' is NOT a physical timestamp: spacing is a user-chosen injection schedule.
Write operations are rejected because the old Simulation model ignores writes.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path

from .v38_trace_ingest import iter_csv
from .model import Simulation
from .memory_controller import lpddr5x_8533


def to_network_trace(events, spacing: int = 5) -> list[tuple]:
    if spacing < 1:
        raise ValueError("spacing must be positive")
    out = []
    t = 0
    for e in events:
        if e.op == "W":
            raise ValueError("Legacy network proxy does not model writes/coherency: refusing W trace")
        owner = {"P": "P0", "E": "E0", "GPU": "GPU", "NPU": "NPU"}[e.agent]
        first = e.address // 64
        last = (e.address + e.size - 1) // 64
        for line in range(first, last + 1):
            out.append((t, e.agent, owner, line, False))
            t += spacing
    return out


def replay(input_csv: Path, spacing: int = 5, max_cycles: int = 100_000) -> dict:
    # RAW traces are accepted here as an address-locality experiment, not proof
    # of physical address sharing or cycle timestamps. CPU/GPU aliasing NOT modeled.
    events = iter_csv(input_csv)
    trace = to_network_trace(events, spacing)
    if not trace:
        raise ValueError("Cannot replay empty trace")
    sim = Simulation(clustered=True, fat=True, trace=trace,
                     max_cycles=max_cycles, memory_cfg=lpddr5x_8533(),
                     borrowable_l3=True, distributed_memory=True)
    result = sim.run()
    result["trace_source"] = str(input_csv)
    result["trace_read_only"] = True
    result["order_spacing_cycles_ASSUMED"] = spacing
    result["trace_limitations"] = (
        "Not gem5; synthetic injection timing; mixed virtual/physical address spaces "
        "not reconciled; no write/fence/coherence; CPU owners collapsed to P0/E0"
    )
    return result


def cli():
    a = argparse.ArgumentParser()
    a.add_argument("input_csv", type=Path)
    a.add_argument("--spacing", type=int, default=5)
    a.add_argument("--max-cycles", type=int, default=100_000)
    a.add_argument("--output", type=Path)
    args = a.parse_args()
    result = replay(args.input_csv, args.spacing, args.max_cycles)
    if args.output:
        args.output.parent.mkdir(exist_ok=True, parents=True)
        args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("trace_requests", "completed", "unfinished",
                                          "GPU", "CPU_P", "CPU_E", "cycles")}, indent=2))
    return result

if __name__ == "__main__":
    cli()
