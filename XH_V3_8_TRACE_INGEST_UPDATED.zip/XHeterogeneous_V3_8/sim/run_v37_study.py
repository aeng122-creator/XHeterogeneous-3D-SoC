"""Reproducible V3.7 study. All included traces are SYNTHETIC.

Run from project root: python -m sim.run_v37_study [--trace CSV] [--out JSON]
Real request traces can be provided via --trace, but no such trace ships here.
"""
from __future__ import annotations
import argparse
import json
import random
from pathlib import Path

from .v37_advanced_power_core import (
    TraceAccess, read_trace_csv, HBMLineCache, VerticalFabric, Packet,
    AdvancedMemoryAndThermalCore,
)

ROOT = Path(__file__).resolve().parents[1]


def synthetic_trace(kind: str, count=6000, seed=37):
    rng = random.Random(seed)
    owners = ("P", "E", "GPU", "NPU")
    out=[]
    for i in range(count):
        if kind == "streaming":
            line=100_000+i
        elif kind == "hot":
            line=i % 96
        elif kind == "mixed":
            line=rng.randrange(96) if rng.random()<.75 else 100_000+i
        else: raise ValueError(kind)
        out.append(TraceAccess(i//4,owners[i%4],line*64))
    return out


def summarize_hbm(trace, capacity_lines=256):
    c=HBMLineCache(capacity_lines)
    c.run(trace)
    return c.summary()


def run_full(trace_path=None):
    scenarios={}
    for kind in ("streaming","hot","mixed"):
        sample=synthetic_trace(kind)
        scenarios[kind]={"HBM_256_lines":summarize_hbm(sample,256),
                         "HBM_64_lines":summarize_hbm(sample,64)}
    if trace_path:
        scenarios["external_trace"]={"source":str(trace_path),
                                       "HBM_256_lines":summarize_hbm(read_trace_csv(trace_path),256)}

    coherence=HBMLineCache(2)
    events=[TraceAccess(0,"P",0x1000,"W",42),
            TraceAccess(1,"GPU",0x1000,"R"),
            TraceAccess(2,"GPU",0x1000,"W",99),
            TraceAccess(3,"P",0x1000,"R"),
            TraceAccess(4,"E",0x2000,"R"),
            TraceAccess(5,"E",0x3000,"R")]
    coherence_outputs=coherence.run(events)
    coherence_summary={"tokens_observed": [r.token for _,r in coherence_outputs],
                       "after_eviction_ddr_token":coherence.ddr.get(0x1000//64),
                       **coherence.summary()}

    # Single TSV gateway vs four physically distributed *assumed* gateways.
    burst=[Packet(i//4,(1,0),"P" if i%2 else "E",i) for i in range(600)]
    one=VerticalFabric(gateways=[(1,0)],depth=8)
    four=VerticalFabric(depth=8)
    for p in burst:
        one.route(p,adaptive=False)
        four.route(p,adaptive=True)
    vertical={"single_gateway":one.summary(),"four_gateways":four.summary(),
              "loop_free_paths_checked":len(four.routes)}

    cfg=ROOT/"config"/"thermal_rc.json"
    power=AdvancedMemoryAndThermalCore(cfg)
    domains={"P":56.0,"E":48.0,"GPU":30.0,"NPU":10.0}
    fixed={"HBM":14.0,"cache":17.0,"NoC":4.51,"IO":11.0,"other":9.0}
    samples=[]
    maximum=0
    failed=[]
    for i in range(1200):  # dt=.1s => 120 s thermal and power time evolution
        o=power.run_step(domains,fixed,dt_s=.1)
        maximum=max(maximum,o["applied_power_w"])
        if not o["power_cap_met"]: failed.append(i)
        if i in (0,9,19,24,29,199,599,1199): samples.append(o)
    power_out={"raw_request_w":round(sum(domains.values())+sum(fixed.values()),3),
               "maximum_applied_w":round(maximum,3),
               "final_sustained_w":samples[-1]["applied_power_w"],
               "unsafe_steps":failed, "samples":samples,
               "calibration":"UNVALIDATED nominal-domain power and thermal RC; not PDK/HotSpot/3D-ICE calibrated"}

    return {"project":"X-Heterogeneous V3.7 prototype",
            "data_class":"Synthetic memory references and assumed power/thermal parameters",
            "hbm":{"cacheline_bytes":64,"synthetic_scenarios":scenarios,
                   "coherence_sequential_proxy":coherence_summary},
            "vertical_fabric":vertical, "power_thermal":power_out,
            "limitations":["No real CPU/GPU application trace supplied",
                "HBM modeled as a sparse LRU line/tag cache; DDR is a token store",
                "No complete MESI/CHI protocol, write buffers, fences or races",
                "No flit-level VC credits or formal deadlock freedom proof",
                "TSV four-cycle latency is an ASSUMPTION, not measured",
                "Power and RC thermal constants uncalibrated; no silicon/CFD/PDK"]}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--trace",type=Path,help="Optional real memory-reference CSV provided by user")
    ap.add_argument("--out",type=Path,default=ROOT/"results"/"v3_7_study.json")
    args=ap.parse_args()
    results=run_full(args.trace)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(results,indent=2,ensure_ascii=False),encoding="utf8")
    for scenario, value in results["hbm"]["synthetic_scenarios"].items():
        print(f"HBM {scenario:10s}: {100*value['HBM_256_lines']['hit_rate']:.2f}% (256 lines) / "
              f"{100*value['HBM_64_lines']['hit_rate']:.2f}% (64 lines)")
    v=results["vertical_fabric"]
    print(f"Vertical TSV proxy P95: one gateway {v['single_gateway']['p95_cycles']}, "
          f"four gateways {v['four_gateways']['p95_cycles']} cycles")
    p=results["power_thermal"]
    print(f"Power: requested {p['raw_request_w']}W, max applied {p['maximum_applied_w']}W, "
          f"sustained at end {p['final_sustained_w']}W")
    print(f"Saved results: {args.out}")


if __name__=="__main__":main()
