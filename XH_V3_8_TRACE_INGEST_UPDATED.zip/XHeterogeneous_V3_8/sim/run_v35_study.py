"""V3.5 repeatable LPDDR5X-8533 vs Quad-DDR5-6400 timing+energy sensitivity study.

Uses synthetic offered bandwidth and a cycle-stepped byte-fair external DRAM proxy.
This is NOT JEDEC cycle-accurate, gem5, GPGPU-Sim, a benchmark or 8K renderer.
"""
from __future__ import annotations
import argparse
import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean
from sim.memory_controller import ORDER, MemoryConfig, WeightedMemoryController,quad_ddr5_6400,lpddr5x_8533,CLOCK_HZ
from sim.model import Simulation,make_trace
from sim.xe2_gpu import Arc140VProxy
from sim.power_controller import PowerController,ProtectionConfig
from sim.run_power_protection import PROFILES

BASE_GBS={'P':30.0,'E':10.0,'GPU':160.0,'NPU':4.7}

def generate_offered_load(cycles:int=5000, multiplier:float=1.,base=None):
    """Reproducible timestamps: accumulate bytes per cycle in each traffic class."""
    if cycles<=0 or multiplier<=0:raise ValueError('Positive cycles/multiplier required')
    base=base or BASE_GBS
    acc={cl:0. for cl in ORDER}
    serial={cl:0 for cl in ORDER}
    trace=[];rid=0
    for t in range(cycles):
        for cl in ORDER:
            acc[cl]+=base[cl]*multiplier*1e9/CLOCK_HZ
            while acc[cl]>=64-1e-10:
                acc[cl]-=64
                serial[cl]+=1
                # Deterministic mixed address pattern to exercise channel hashing.
                offset={'P':100_000, 'E':200_000,'GPU':500_000,'NPU':900_000}[cl]
                line=(offset+serial[cl]*0x9e3779b1) & 0xffffffff
                trace.append((t,rid,cl,line))
                rid+=1
    return trace


def percentile(nums,p):
    if not nums:return None
    y=sorted(nums)
    return y[min(len(y)-1,int((len(y)-1)*p))]


def simulate_memory(cfg:MemoryConfig,trace,inject_cycles:int,drain_limit_cycles=150_000):
    mc=WeightedMemoryController(cfg)
    issued_at={rid:t for t,rid,cl,line in trace}
    t_index=0
    n=len(trace)
    pending_ready=[]
    completion={cl:[] for cl in ORDER}
    at_injection_end=None
    for t in range(drain_limit_cycles):
        while t_index<n and trace[t_index][0]<=t:
            inj,rid,cl,line=trace[t_index]
            mc.submit(rid,cl,line,t)
            t_index+=1
        for ready,rid in mc.tick(t):
            # Fully modeled fixed latency/codec delay added by controller.
            pending_ready.append((ready,rid))
        if t==inject_cycles-1:
            at_injection_end=mc.peak_backlog if mc.peak_backlog else 0
            actual_pending=mc.active.count(None)
        if t_index==n and not mc.pending():
            break
    else:
        raise RuntimeError('Memory controller failed to drain')
    lookup={rid:cl for _,rid,cl,_ in trace}
    for ready,rid in pending_ready:
        completion[lookup[rid]].append(ready-issued_at[rid])
    # All transfers have completed, but final fixed-latency read may still be traveling.
    last_ready=max((ready for ready,_ in pending_ready),default=inject_cycles)
    snapshot=mc.snapshot(t+1)
    snapshot.update(injection_cycles=inject_cycles,
                    transfer_drained_at_cycle=t+1,
                    latest_response_ready_cycle=last_ready,
                    extra_drain_cycles=max(0,t+1-inject_cycles),
                    total_requests=n,
                    offered_logical_gbs=round(sum(v for v in BASE_GBS.values())*(n/sum(1 for _ in trace) if n else 0),3) if False else round(n*64*CLOCK_HZ/1e9/inject_cycles,3),
                    offered_physical_gbs=round(snapshot['transferred_physical_bytes']*CLOCK_HZ/1e9/inject_cycles,3),
                    guaranteed_E_min_fraction_if_backlogged=cfg.qos_weights['E'],
                    P95_response_cycles={cl:percentile(completion[cl],.95) for cl in ORDER},
                    P99_response_cycles={cl:percentile(completion[cl],.99) for cl in ORDER},
                    mean_response_cycles={cl:round(mean(completion[cl]),1) if completion[cl] else None for cl in ORDER})
    return snapshot


def run_pair(injection_cycles=5000,multiplier=1.0,compression=.5):
    trace=generate_offered_load(injection_cycles,multiplier)
    configurations=[('ddr5_quad',quad_ddr5_6400()),
                    ('lpddr5x_no_compression',lpddr5x_8533(compression=0)),
                    ('lpddr5x_compression',lpddr5x_8533(compression=compression))]
    return {name:simulate_memory(cfg,trace,injection_cycles) for name,cfg in configurations}


def power_study():
    demand,uncore=PROFILES['extreme']
    report={}
    for extra in [0,4,8]:
        ctrl=PowerController(ProtectionConfig())
        peak=0.;first=None;last=None
        for t in range(5000):
            row=ctrl.step(demand,uncore+extra)
            if first is None:first=row
            last=row
            peak=max(peak,row['applied_power_w'])
        report[f'additional_uncore_{extra}W']={
            'requested_w':round(sum(demand.values())+uncore+extra,3),
            'boost_first_w':first['applied_power_w'],
            'peak_applied_w':round(peak,3),
            'final_power_w':last['applied_power_w'],
            'last_mode':last['mode'],'final_clocks':last['clocks'],
            'thermal_tiers_c':[last['tier1_c'],last['tier2_c']],
            'warning':'Added memory/PHY power is assumed; no power extraction.'}
    return report


def study():
    scenarios={
        'mixed':run_pair(injection_cycles=5000,multiplier=1.),
        'heavy_130pct':run_pair(injection_cycles=5000,multiplier=1.3),
        'extreme_160pct':run_pair(injection_cycles=5000,multiplier=1.6),
        'uncompressible_100pct':run_pair(injection_cycles=5000,multiplier=1.,compression=0),
    }
    # Paired full synthetic NoC + cache experiment, preserving the same injection trace.
    trace=make_trace(seed=117,cycles=1350,intensity=2.2)
    network={
        'quad_ddr5':Simulation(True,True,trace=trace,max_cycles=95_000,
                               memory_cfg=quad_ddr5_6400(),borrowable_l3=False,distributed_memory=True).run(),
        'lpddr5x_shared_l3':Simulation(True,True,trace=trace,max_cycles=95_000,
                               memory_cfg=lpddr5x_8533(),borrowable_l3=True,distributed_memory=True).run()
    }
    gpu=Arc140VProxy()
    roofline={}
    for key,rate in [('quad_ddr5',quad_ddr5_6400().sustained_gbs),('lpddr5x',lpddr5x_8533().sustained_gbs)]:
        # For equal 30% CPU share / 70% GPU share at the DRAM bottleneck.
        model=Arc140VProxy(shared_ddr_peak_gbs=rate/.75,shared_ddr_sustained_proxy_gbs=rate)
        roofline[key]={'light':model.roofline(flops_per_pixel=1000,external_bytes_per_pixel=32,ddr_gpu_share=.7),
                       'heavy':model.roofline(flops_per_pixel=20000,external_bytes_per_pixel=128,ddr_gpu_share=.7)}
    return {'status':'Synthetic cycle-stepped proxy, not calibrated chip or cycle-accurate GPU/JEDEC model',
            'memory_options':{'DDR5-6400':quad_ddr5_6400().__dict__,
                              'LPDDR5X-8533':lpddr5x_8533().__dict__},
            'scenarios':scenarios,'paired_network':network,'power_sensitivity':power_study(),
            'optimistic_8k_roofline':roofline,
            'limitations':['Compression assumes half GPU lines transfer at half byte size; not measured.',
                           'DDR LP channel service is byte-credit based; not a JEDEC bank/refresh/command simulator.',
                           'QoS weights are byte fair only when classes are continuously backlogged and channel hashes are balanced.',
                           'Memory time is not coupled to DVFS during network experiments.',
                           'No measured IPC, GPU rendering, memory PHY/power, or thermal silicon results.']}


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='results/v3_5_study.json')
    a=p.parse_args()
    result=study()
    dest=Path(a.out);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
    print('X-Heterogeneous V3.5 synthetic memory and iGPU test')
    for name,rows in result['scenarios'].items():
        print('\nSCENARIO',name)
        for config,v in rows.items():
            print(f'{config:<28} request_phy={v["offered_physical_gbs"]:>7} GB/s  '
                  f'extra_drain={v["extra_drain_cycles"]:>6} cyc  '
                  f'GPU-P95={v["P95_response_cycles"]["GPU"]:>6} cyc  '
                  f'P-P95={v["P95_response_cycles"]["P"]:>6} cyc')
    print('\nPaired network paths')
    for name,v in result['paired_network'].items():
        print(name,'GPU P95',v['GPU']['p95_cycles'],'CPU P95',v['CPU_P']['p95_cycles'],
              'GPU borrow hiwater',v['gpu_l3_borrowed_highwater_scaled_bytes'],
              'complete',v['completed'],'/',v['trace_requests'])
    print('Saved',dest)
if __name__=='__main__':main()
