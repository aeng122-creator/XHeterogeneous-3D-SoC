@echo off
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3.10 or later is required.
  pause
  exit /b 1
)
python -m unittest discover -s tests -q
if errorlevel 1 (
  echo Test suite failed.
  pause
  exit /b 1
)
python -m sim.v38_trace_ingest --cpu-trace EXAMPLE_SYNTHETIC_pinatrace.txt --gpu-trace EXAMPLE_SYNTHETIC_GPU_CYCLES.csv --hbm-input EXAMPLE_SYNTHETIC_hbm_in.csv --capacity-lines 4 --output results\V3_8_TRACE_DEMO.json
pause
