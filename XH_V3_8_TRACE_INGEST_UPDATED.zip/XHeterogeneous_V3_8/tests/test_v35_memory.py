"""V3.5 realistic-scope tests for memory bandwidth model and pooled L3.
Run: python -m unittest discover -s tests -v
"""
import unittest
from sim.memory_controller import MemoryConfig,WeightedMemoryController,quad_ddr5_6400,lpddr5x_8533
from sim.shared_l3 import BorrowableL3Bank
from sim.run_v35_study import generate_offered_load, simulate_memory
from sim.model import Mesh,make_trace,Simulation
from sim.power_controller import ProtectionConfig,PowerController
from sim.run_power_protection import PROFILES

class V35MemoryConfigTests(unittest.TestCase):
    def test_ddr5_bandwidth(self):
        x=quad_ddr5_6400()
        self.assertEqual((x.mtps,x.width_bits,x.channels),(6400,256,4))
        self.assertAlmostEqual(x.peak_gbs,204.8)
        self.assertAlmostEqual(x.sustained_gbs,153.6)
    def test_lpddr5x_bandwidth(self):
        x=lpddr5x_8533()
        self.assertEqual((x.mtps,x.width_bits,x.channels),(8533,256,8))
        self.assertAlmostEqual(x.peak_gbs,273.056)
        self.assertAlmostEqual(x.sustained_gbs,204.792)
    def test_invalid_config(self):
        with self.assertRaises(ValueError):MemoryConfig('bad',8533,256,3)
        with self.assertRaises(ValueError):lpddr5x_8533(compression=1.2)
    def test_gpu_compression_does_not_change_cpu_bytes(self):
        mc=WeightedMemoryController(lpddr5x_8533())
        for k in range(2000):
            mc.submit(k,'P',k*99,0)
        self.assertEqual(mc.stats['physical_bytes_P'],mc.stats['logical_bytes_P'])
    def test_gpu_compression_reduces_physical_bytes(self):
        mc=WeightedMemoryController(lpddr5x_8533())
        for k in range(2000):mc.submit(k,'GPU',k*99,0)
        self.assertLess(mc.stats['physical_bytes_GPU'],mc.stats['logical_bytes_GPU'])
        self.assertGreater(mc.stats['compressed_gpu_requests'],800)
    def test_work_conserving_qos_guarantees_e_backlogged_share(self):
        mc=WeightedMemoryController(quad_ddr5_6400())
        classes=('P','E','GPU','NPU')
        for k in range(1500):
            for j,cls in enumerate(classes):
                mc.submit(k*4+j,cls,k*256+j,0)
        for t in range(1500):mc.tick(t)
        done=sum(mc.stats['completed_'+c] for c in classes)
        self.assertGreater(done,700)
        self.assertGreaterEqual(mc.stats['completed_E']/done,.12)
    def test_reproducible_trace(self):
        self.assertEqual(generate_offered_load(200),generate_offered_load(200))
    def test_lp_reduces_memory_queue_at_mixed_load(self):
        trace=generate_offered_load(2000)
        a=simulate_memory(quad_ddr5_6400(),trace,2000)
        b=simulate_memory(lpddr5x_8533(),trace,2000)
        self.assertEqual(a['completed_memory_jobs'],len(trace))
        self.assertEqual(b['completed_memory_jobs'],len(trace))
        self.assertLess(b['P95_response_cycles']['GPU'],a['P95_response_cycles']['GPU'])
        self.assertLess(b['transferred_physical_bytes'],a['transferred_physical_bytes'])
        self.assertLess(b['extra_drain_cycles'],a['extra_drain_cycles'])
    def test_no_compression_fallback_lossless_model(self):
        trace=generate_offered_load(1000)
        x=simulate_memory(lpddr5x_8533(compression=0),trace,1000)
        self.assertEqual(x['transferred_logical_bytes'],x['transferred_physical_bytes'])

class V35CacheTopologyTests(unittest.TestCase):
    def test_gpu_borrows_when_cpu_not_using_its_share(self):
        # Miniature bank: 120 B CPU soft target, 20 B GPU soft target.
        bank=BorrowableL3Bank(140,120,20)
        for x in range(4):bank.put(400+x,'GPU')
        self.assertLessEqual(sum(bank.used.values()),140)
        self.assertGreater(bank.used['GPU'],20)
        self.assertGreater(bank.stats['gpu_borrowed_highwater'],0)
    def test_cpu_reclaims_gpu_borrowed_capacity(self):
        bank=BorrowableL3Bank(140,120,20)
        for k in range(3):bank.put(400+k,'GPU')
        gpu0=bank.used['GPU']
        for k in range(15):bank.put(700+k,'CPU')
        self.assertLessEqual(sum(bank.used.values()),bank.capacity)
        self.assertLess(bank.used['GPU'],gpu0)
    def test_distributed_controller_endpoints_without_new_routers(self):
        mesh=Mesh(True,True,memory_ports=8)
        self.assertEqual(mesh.n,28)
        self.assertEqual(len(set(mesh.endpoint[f'MEM_{i}'] for i in range(8))),8)
    def test_simulation_full_chain(self):
        trace=make_trace(seed=5,cycles=160,intensity=1.5)
        old=Simulation(True,True,trace=trace,max_cycles=35_000,memory_cfg=quad_ddr5_6400(),distributed_memory=True).run()
        new=Simulation(True,True,trace=trace,max_cycles=35_000,memory_cfg=lpddr5x_8533(),distributed_memory=True,borrowable_l3=True).run()
        self.assertEqual(old['completed'],new['completed'])
        self.assertEqual(new['completed'],len(trace))
        self.assertEqual(new['mem_VRAM_MB'],0)
        self.assertTrue(new['l3_shared_borrow_enabled'])
        self.assertGreater(new['memory_controller']['compressed_gpu_requests'],0)

class V35PowerTests(unittest.TestCase):
    def test_power_limits_same_under_lpddr_uncore_sensitivity(self):
        demand,uncore=PROFILES['extreme']
        for extra in (0,4,8):
            c=PowerController(ProtectionConfig())
            peak=0
            for _ in range(3000):
                row=c.step(demand,uncore+extra)
                peak=max(peak,row['applied_power_w'])
            self.assertLessEqual(peak,180)
            self.assertLessEqual(row['applied_power_w'],120.001)
            self.assertGreater(c.state.preventive_events,0)

if __name__=='__main__':unittest.main()
