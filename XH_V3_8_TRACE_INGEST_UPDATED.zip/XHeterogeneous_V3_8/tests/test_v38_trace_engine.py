import tempfile
import unittest
from pathlib import Path
from sim.v38_trace_ingest import TraceIngestionEngine


class HighLevelIngestionTests(unittest.TestCase):
    def test_pin_is_raw_not_measured_hbm(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'c.txt'
            p.write_text('R 0x1000 8\nW 0x2000 4\nR 0x1000 8\n')
            r = TraceIngestionEngine(d, capacity_lines=4).ingest_cpu_pinatrace(p.name)
            self.assertEqual(r['Total Memory Operands'], 3)
            self.assertEqual(r['Bounded RAW Operand Reuse Ratio'], 33.33)
            self.assertIsNone(r['Dynamic HBM Hit Rate'])
            self.assertIsNone(r['Cache Compressions Triggered'])

    def test_hbm_replay_with_eviction_is_not_unique_ratio(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'h.csv'
            p.write_text('agent,address,op,boundary\nP,0x0000,R,HBM_IN\nGPU,0x0040,R,HBM_IN\nP,0x0080,R,HBM_IN\nP,0x0000,R,HBM_IN\n')
            r = TraceIngestionEngine(d, capacity_lines=2).ingest_hbm_address_trace('h.csv')
            self.assertEqual(r['hits'], 0)
            self.assertEqual(r['misses'], 4)
            self.assertEqual(r['evictions'], 2)

    def test_raw_csv_is_rejected_for_hbm_replay(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'h.csv'; p.write_text('agent,address,op,boundary\nP,0x0,R,RAW\n')
            with self.assertRaises(ValueError):
                TraceIngestionEngine(d).ingest_hbm_address_trace('h.csv')

    def test_gpu_cycle_bytes_math_decimal_gbs(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'g.csv'; p.write_text('cycle,bytes\n0,100\n1,100\n')
            r=TraceIngestionEngine(d,clock_ghz=2.5,sustainable_memory_gbs=204.79).ingest_gpu_hbm_trace('g.csv')
            self.assertEqual(r['Simulated Cycles'], 2)
            self.assertEqual(r['Average Bandwidth Demand GBps'], 250.0)
            self.assertEqual(r['Demand vs Assumed Memory Budget'], 'Above assumed budget')
            self.assertIsNone(r['Dynamic HBM Hit Rate'])

    def test_gpu_sparse_cycle_span(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'g.csv'; p.write_text('10,100\n19,100\n')
            r=TraceIngestionEngine(d,clock_ghz=2.5).ingest_gpu_hbm_trace('g.csv')
            self.assertEqual(r['Simulated Cycles'],10)
            self.assertAlmostEqual(r['Average Bandwidth Demand GBps'],50.)

    def test_gpu_normalized_trace_no_fake_bandwidth(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'h.csv'; p.write_text('order,agent,address,op,boundary,size\n0,GPU,0x1000,R,HBM_IN,64\n1,GPU,0x1000,R,HBM_IN,64\n')
            r=TraceIngestionEngine(d).ingest_gpu_hbm_trace('h.csv')
            self.assertEqual(r['GPU HBM Hit Rate'], '50.00%')
            self.assertIsNone(r['Average Bandwidth Demand'])

    def test_gpu_rejects_negative_and_unordered(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'g.csv'; p.write_text('cycle,bytes\n1,100\n0,100\n')
            with self.assertRaises(ValueError):
                TraceIngestionEngine(d).ingest_gpu_hbm_trace('g.csv')
            p.write_text('cycle,bytes\n1,-2\n')
            with self.assertRaises(ValueError):
                TraceIngestionEngine(d).ingest_gpu_hbm_trace('g.csv')

    def test_missing_returns_error_without_keyerror(self):
        with tempfile.TemporaryDirectory() as d:
            engine=TraceIngestionEngine(d)
            self.assertEqual(engine.ingest_cpu_pinatrace('not-present.txt')['status'],'Error')
            self.assertEqual(engine.ingest_gpu_hbm_trace('not-present.csv')['status'],'Error')

if __name__=='__main__':
    unittest.main()
