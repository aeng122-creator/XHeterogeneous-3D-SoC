import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from sim.power_controller import PowerController,ProtectionConfig
from sim.run_power_protection import run_scenario,PROFILES

class PowerProtectionTests(unittest.TestCase):
    def test_limits_order(self):
        c=ProtectionConfig();self.assertEqual((c.sustained_w,c.preventive_w,c.boost_max_w),(120,170,180))
    def test_guard_begins_at_170(self):
        p=PowerController()
        below=p.step({'P':50,'E':35,'GPU':55,'NPU':5},24) # 169W
        self.assertNotIn('PREVENTIVE_170W',below['events'])
        at=p.step({'P':50,'E':35,'GPU':55,'NPU':5},25) # 170W
        self.assertIn('PREVENTIVE_170W',at['events'])
        above=p.step({'P':50,'E':35,'GPU':55,'NPU':5},28) # 173W
        self.assertLess(above['applied_power_w'],above['raw_request_w'])
    def test_fast_clamp_demand_exceeds_180(self):
        p=PowerController();r=p.step(*PROFILES['extreme'])
        self.assertGreater(r['raw_request_w'],180)
        self.assertIn('HARD_POWER_CLAMP',r['events'])
        self.assertLessEqual(r['applied_power_w'],180.001)
    def test_boost_credit_expires_and_sustained_demand_caps(self):
        p=PowerController()
        for _ in range(3600):r=p.step(*PROFILES['extreme'])
        self.assertEqual(r['mode'],'SUSTAINED')
        self.assertLessEqual(r['applied_power_w'],120.001)
        self.assertEqual(p.state.boost_credit_j,0)
    def test_idle_recharges_energy_credit(self):
        p=PowerController()
        for _ in range(3500):p.step(*PROFILES['extreme'])
        old=p.state.boost_credit_j
        for _ in range(200):p.step(*PROFILES['idle'])
        self.assertGreater(p.state.boost_credit_j,old)
    def test_sensor_invalid_goes_safe(self):
        p=PowerController();r=p.step(*PROFILES['extreme'],sensor_ok=False)
        self.assertIn('SENSOR_FAULT_SAFE_MODE',r['events'])
        self.assertLessEqual(r['applied_power_w'],100.001)
    def test_fault_latches_until_explicit_reset(self):
        p=PowerController()
        p.step(*PROFILES['extreme'],sensor_ok=False)
        good=p.step(*PROFILES['extreme'],sensor_ok=True)
        self.assertIn('SENSOR_FAULT_LATCHED',good['events'])
        self.assertLessEqual(good['applied_power_w'],100.001)
        self.assertFalse(p.clear_latched_faults(sensors_verified=True,physical_reset=False))
        self.assertTrue(p.clear_latched_faults(sensors_verified=True,physical_reset=True))
        restored=p.step(*PROFILES['extreme'],sensor_ok=True)
        self.assertGreater(restored['applied_power_w'],100)
    def test_sensor_stale_goes_safe(self):
        p=PowerController();r=p.step(*PROFILES['extreme'],sensor_age_s=.020)
        self.assertIn('SENSOR_FAULT_SAFE_MODE',r['events'])
        self.assertLessEqual(r['applied_power_w'],100.001)
    def test_thermal_limit(self):
        p=PowerController();p.state.tier2_c=99
        r=p.step(*PROFILES['extreme'])
        self.assertIn('THERMAL_LIMIT_95C',r['events'])
        self.assertLessEqual(r['applied_power_w'],100.001)
    def test_thermal_trip_latches(self):
        p=PowerController();p.state.tier1_c=106
        first=p.step(*PROFILES['extreme']);second=p.step(*PROFILES['idle'])
        self.assertEqual(first['mode'],'TRIP');self.assertEqual(first['applied_power_w'],0)
        self.assertEqual(second['mode'],'TRIP')
    def test_all_power_runs_under_cap(self):
        for name in PROFILES:
            r=run_scenario(name,seconds=3)
            self.assertLessEqual(r['max_applied_w'],180.001)

if __name__=='__main__':unittest.main()
