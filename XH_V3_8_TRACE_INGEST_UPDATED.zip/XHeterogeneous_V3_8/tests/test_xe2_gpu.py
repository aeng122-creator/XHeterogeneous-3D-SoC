import unittest
from sim.xe2_gpu import Arc140VProxy
from sim.run_power_protection import PROFILES,run_scenario

class ArcClassModelTests(unittest.TestCase):
    def test_reference_units(self):
        g=Arc140VProxy()
        self.assertEqual(g.xe_cores,8)
        self.assertEqual(g.vector_engines,64)
        self.assertAlmostEqual(g.max_clock_ghz,1.95)
        self.assertAlmostEqual(g.ideal_fp32_tflops,3.9936)
    def test_synthetic_roofline_bounds(self):
        g=Arc140VProxy()
        low=g.roofline(flops_per_pixel=1000)
        heavy=g.roofline(flops_per_pixel=20000)
        self.assertGreater(heavy['roofline_frame_time_lower_bound_ms'],low['roofline_frame_time_lower_bound_ms'])
        less_gpu_memory=g.roofline(flops_per_pixel=1000,ddr_gpu_share=.20)
        self.assertGreater(less_gpu_memory['roofline_frame_time_lower_bound_ms'],low['roofline_frame_time_lower_bound_ms'])
    def test_gpu_clock_scales_roofline(self):
        g=Arc140VProxy()
        base=g.roofline(flops_per_pixel=20000,clock_scale=1)
        slow=g.roofline(flops_per_pixel=20000,clock_scale=.5)
        self.assertGreater(slow['roofline_frame_time_lower_bound_ms'],base['roofline_frame_time_lower_bound_ms'])
    def test_gpu_power_updated(self):
        self.assertEqual(PROFILES['extreme'][0]['GPU'],30)
        self.assertEqual(PROFILES['moderate'][0]['GPU'],25)
        self.assertAlmostEqual(sum(PROFILES['extreme'][0].values())+PROFILES['extreme'][1],185.509)
    def test_protection_still_active(self):
        r=run_scenario('extreme',seconds=3)
        self.assertLessEqual(r['max_applied_w'],180)
        self.assertGreater(r['prevention_count'],0)
        self.assertGreater(r['boost_exhausted_steps'],0)

if __name__=='__main__':unittest.main()
