import unittest
from sim.v36_prototype import HybridConfig,AdaptiveCompression,HybridMemory,make_stress_trace,VerticalNetwork,ThermalRC,load_thermal
from sim.run_v36_study import study

class HybridV36Tests(unittest.TestCase):
    def test_peak_bandwidth(self):
        self.assertAlmostEqual(HybridConfig().hbm_sustained_gbs,573.44,places=2)
        self.assertAlmostEqual(HybridConfig().ddr_sustained_gbs,153.6,places=2)
    def test_codec_bypass_entropy(self):
        m=AdaptiveCompression()
        self.assertEqual(m.evaluate('GPU','random'),(64,0))
        self.assertEqual(m.evaluate('GPU','zero'),(32,14))
        self.assertEqual(m.evaluate('P','zero'),(64,0))
    def test_no_packet_loss(self):
        trace=make_stress_trace(cycles=200,demand_gbs=263.62,hbm_hit_fraction=.55)
        result=HybridMemory(HybridConfig()).simulate(trace)
        self.assertEqual(result['issued'],result['completed'])
    def test_hit_saves_ddr(self):
        a=HybridMemory(HybridConfig()).simulate(make_stress_trace(cycles=800,hbm_hit_fraction=.20))
        b=HybridMemory(HybridConfig()).simulate(make_stress_trace(cycles=800,hbm_hit_fraction=.75))
        self.assertGreater(a['ddr_total_bytes'],b['ddr_total_bytes'])
        self.assertGreater(a['ddr_peak_backlog'],b['ddr_peak_backlog'])
    def test_high_entropy_has_no_codec_latency(self):
        trace=[(0,1,'GPU',123,'random',True)]
        r=HybridMemory(HybridConfig(compression=True)).simulate(trace)
        self.assertEqual(r['codec'].get('compressed',0),0)
        self.assertEqual(r['codec'].get('gpu_bypass_entropy',0),1)
    def test_direct_gpu_same_tier_not_tsv(self):
        v=VerticalNetwork()
        r=v.run([0,0,0,0],local_gpu=True)
        self.assertTrue(r['bypassed_tsv_for_upper_gpu_l3'])
        self.assertTrue(all(not k for k in r['per_gateway_packets'].values()))
    def test_escape_gateway_reduces_congestion(self):
        v=VerticalNetwork()
        a=v.run([t for t in range(100) for _ in range(2)],adaptive=False)
        b=v.run([t for t in range(100) for _ in range(2)],adaptive=True)
        self.assertLess(b['p95_cycles'],a['p95_cycles'])
        self.assertEqual(sum(b['per_gateway_packets'].values()),200)
    def test_thermal_stable(self):
        th=ThermalRC(load_thermal())
        result=th.simulate({'bottom_cpu_tier':108,'top_gpu_l3_tier':60,'adjacent_hbm3_stack':12},seconds=120)
        self.assertEqual(len(result),3)
        self.assertGreater(result[-1]['nodes_C']['bottom_cpu_tier'],30)
        self.assertLess(max(result[-1]['nodes_C'].values()),200)
    def test_power_scope_includes_hbm(self):
        data=load_thermal()
        self.assertIn('INCLUDES HBM3',data['power_budget_scope'])
    def test_study_works(self):
        d=study(cycles=100)
        self.assertIn('memory_hit_sensitivity',d)
        self.assertEqual(d['hardware_constraints']['silicon_tiers'],2)

if __name__=='__main__':unittest.main()

class RoutingAndIsolationTests(unittest.TestCase):
    def test_l3_domains_do_not_evict_each_other(self):
        from sim.v36_prototype import IsolatedL3
        c=IsolatedL3(scale=16384)
        c.access('CPU',42)
        for i in range(10000):c.access('GPU',i)
        self.assertTrue(c.access('CPU',42,insert=False))
        self.assertLessEqual(c.size('GPU'),c.max_lines['GPU'])
    def test_escape_route_with_peripheral_detour(self):
        from sim.v36_prototype import EscapeRoutingPolicy
        p=EscapeRoutingPolicy()
        start=(0,1);end=(6,1)
        edge_load={(u,v):100 for u,v in zip(p.xy(start,end),p.xy(start,end)[1:])}
        found=p.choose(start,end,edge_load)
        self.assertEqual(found['selected'],'perimeter')
        self.assertEqual(found['escape_path'],p.xy(start,end))
        self.assertEqual(len(found['path']),len(set(found['path'])))
    def test_xy_fallback_deadlock_baseline_only(self):
        from sim.v36_prototype import EscapeRoutingPolicy
        p=EscapeRoutingPolicy()
        r=p.choose((0,1),(6,2),{})
        self.assertEqual(r['escape_vc'],'escape_xy')
        self.assertTrue(r['must_remain_escape_after_fallback'])
