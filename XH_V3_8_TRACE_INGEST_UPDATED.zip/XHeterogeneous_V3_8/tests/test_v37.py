"""V3.7 regression tests for safe bounded *models*, not silicon signoff."""
import csv
import math
import tempfile
import unittest
from pathlib import Path

from sim.v37_advanced_power_core import (
    TraceAccess, HBMLineCache, read_trace_csv,
    Packet, VerticalFabric, ThermalNetwork,
    AdvancedMemoryAndThermalCore, PowerConfig,
)

CFG = Path(__file__).resolve().parents[1]/"config"/"thermal_rc.json"


class TestHBM(unittest.TestCase):
    def test_line_reuse_reports_true_hits(self):
        c=HBMLineCache(4)
        seq=[1024,2048,1024,4096,1024,2048,8192,1024]
        hits=[c.access(TraceAccess(i,"P",a)).hit for i,a in enumerate(seq)]
        self.assertEqual(hits,[False,False,True,False,True,True,False,True])
        self.assertEqual(c.summary()["hit_rate"],.5)

    def test_streaming_zero_hit_no_artificial_floor(self):
        c=HBMLineCache(8)
        for i in range(100):c.access(TraceAccess(i,"GPU",i*64))
        self.assertEqual(c.summary()["hit_rate"],0)
        self.assertEqual(c.summary()["misses"],100)

    def test_repeated_same_line_can_reach_full_hit_after_warmup(self):
        c=HBMLineCache(1)
        for i in range(100):c.access(TraceAccess(i,"E",0))
        self.assertAlmostEqual(c.summary()["hit_rate"],.99)

    def test_eviction_changes_hit_rate(self):
        c=HBMLineCache(2)
        for i,a in enumerate([0,64,128,0]):c.access(TraceAccess(i,"P",a))
        self.assertEqual(c.summary()["hits"],0)
        self.assertEqual(c.summary()["evictions"],2)

    def test_unified_cpu_gpu_visibility_and_writeback(self):
        c=HBMLineCache(2)
        c.access(TraceAccess(0,"P",64,"W",42))
        gpu=c.access(TraceAccess(1,"GPU",64))
        self.assertEqual(gpu.token,42)
        self.assertTrue(gpu.ownership_transfer)
        gpu_write=c.access(TraceAccess(2,"GPU",64,"W",99))
        self.assertEqual(gpu_write.invalidations,1)
        cpu=c.access(TraceAccess(3,"P",64))
        self.assertEqual(cpu.token,99)
        c.access(TraceAccess(4,"P",128))
        c.access(TraceAccess(5,"E",192))
        self.assertEqual(c.ddr[1],99)
        self.assertGreaterEqual(c.counters["ddr_writebacks"],1)

    def test_same_line_different_byte_addresses_share_line(self):
        c=HBMLineCache(1)
        self.assertFalse(c.access(TraceAccess(0,"P",64)).hit)
        self.assertTrue(c.access(TraceAccess(1,"GPU",95)).hit)

    def test_trace_csv_parser(self):
        with tempfile.TemporaryDirectory() as td:
            f=Path(td)/"trace.csv"
            f.write_text("cycle,agent,address,operation,value\n1,GPU,0x40,W,0x2a\n2,P,64,R,0\n")
            a=read_trace_csv(f)
            self.assertEqual((a[0].address,a[0].value,a[1].operation),(64,42,"R"))

    def test_reject_invalid_trace(self):
        for kwargs in ({"cycle":-1,"agent":"P","address":0},
                       {"cycle":1,"agent":"X","address":0},
                       {"cycle":1,"agent":"P","address":-64}):
            with self.assertRaises(ValueError):TraceAccess(**kwargs)


class TestVertical(unittest.TestCase):
    def test_upper_gpu_does_not_use_tsv(self):
        n=VerticalFabric()
        o=n.route(Packet(0,(4,1),"GPU",1))
        self.assertEqual(o["latency"],2)
        self.assertIsNone(o["gateway"])
        self.assertEqual(n.summary()["packets"],0)

    def test_distributed_ports_reduce_burst_queueing(self):
        burst=[Packet(0,(1,0),"P",i) for i in range(200)]
        one=VerticalFabric(gateways=[(1,0)],depth=8)
        four=VerticalFabric(depth=8)
        baseline=[one.route(p)["latency"] for p in burst]
        revised=[four.route(p)["latency"] for p in burst]
        self.assertLess(sorted(revised)[189],sorted(baseline)[189])
        self.assertEqual(four.summary()["packets"],200)
        self.assertGreater(four.summary()["escape_packets"],0)

    def test_escaped_paths_are_non_looping_and_one_way(self):
        n=VerticalFabric(depth=2)
        for i in range(50):
            r=n.route(Packet(0,(1,0),"E",i))
            self.assertEqual(len(r["path"]),len(set(r["path"])))
            self.assertIn(r["vc"],("adaptive_xy","escape_xy"))
        self.assertGreater(n.summary()["escape_packets"],0)

    def test_backpressure_is_reported_not_dropped(self):
        n=VerticalFabric(gateways=[(1,0)],depth=2)
        out=[n.route(Packet(0,(1,0),"P",i)) for i in range(40)]
        self.assertEqual(len(out),40)
        self.assertGreater(n.summary()["backpressure_cycles"],0)

    def test_latency_assumption_is_explicit(self):
        n=VerticalFabric(gateways=[(1,0)],tsv_latency_cycles=4)
        r=n.route(Packet(0,(1,0),"P",0))
        self.assertEqual(r["latency"],5)  # 1 service + 4 link cycles


class TestPowerThermal(unittest.TestCase):
    def make(self,**kw):
        return AdvancedMemoryAndThermalCore(CFG,PowerConfig(**kw))

    def test_high_load_is_clamped_below_180(self):
        p=self.make()
        out=p.run_step({"P":56,"E":48,"GPU":30,"NPU":10},
                       {"cache":17,"NoC":4.51,"IO":11,"HBM":14,"other":9})
        self.assertTrue(out["power_cap_met"])
        self.assertLessEqual(out["applied_power_w"],176.0001)
        self.assertIn("PREVENTIVE_DVFS",out["events"])

    def test_170_prevention_starts_early(self):
        p=self.make()
        out=p.run_step({"P":40,"E":40,"GPU":30,"NPU":10},
                       {"cache":17,"NoC":4,"IO":12,"HBM":10,"other":8})
        self.assertGreater(out["raw_request_w"],170)
        self.assertLess(out["applied_power_w"],out["raw_request_w"])

    def test_120_sustained_after_boost_credit_exhaustion(self):
        p=self.make(boost_credit_j=3)
        results=[]
        for i in range(5):
            results.append(p.run_step({"P":56,"E":48,"GPU":30,"NPU":10},
                                      {"cache":17,"NoC":4.5,"IO":11,"HBM":14,"other":9},dt_s=.1))
        self.assertLessEqual(results[-1]["applied_power_w"],120.001)
        self.assertEqual(results[-1]["boost_credit_j"],0)

    def test_extreme_load_uses_duty_cycle_and_stays_within_cap(self):
        p=self.make(boost_credit_j=0)
        out=p.run_step({"P":900,"E":700,"GPU":400,"NPU":150},
                       {"HBM":14,"cache":20,"IO":10,"NoC":5,"other":5})
        self.assertTrue(out["power_cap_met"])
        self.assertAlmostEqual(out["applied_power_w"],120,places=2)
        self.assertIn("DUTY_CYCLE_STALL",out["events"])

    def test_static_power_over_cap_is_reported_infeasible(self):
        p=self.make(boost_credit_j=0)
        out=p.run_step({"P":1,"E":1,"GPU":1,"NPU":1},{"leakage":125})
        self.assertFalse(out["power_cap_met"])
        self.assertEqual(out["mode"],"INFEASIBLE")
        self.assertGreater(out["applied_power_w"],120)

    def test_sensor_failure_latches_safe_mode(self):
        p=self.make()
        base={"P":1,"E":1,"GPU":1,"NPU":1}
        a=p.run_step(base,{"fixed":40},sensor_ok=False)
        b=p.run_step(base,{"fixed":40},sensor_ok=True)
        self.assertEqual(a["mode"],"TRIPPED")
        self.assertEqual(b["mode"],"TRIPPED")

    def test_thermal_heat_and_cooling(self):
        thermal=ThermalNetwork(CFG)
        hot=thermal.step({"bottom_cpu_tier":90,"top_gpu_l3_tier":50,
                          "adjacent_hbm3_stack":14},60)
        self.assertGreater(hot["bottom_cpu_tier"],thermal.coolant)
        cooler=thermal.step({},120)
        self.assertLess(cooler["bottom_cpu_tier"],hot["bottom_cpu_tier"])

    def test_thermal_energy_distribution(self):
        p=self.make()
        out=p.run_step({"P":20,"E":20,"GPU":10,"NPU":5},
                       {"cache":10,"HBM":10,"other":5},dt_s=.5)
        self.assertAlmostEqual(sum(out["power_by_node_w"].values()),out["applied_power_w"],delta=.01)
        self.assertGreater(out["temps_C"]["adjacent_hbm3_stack"],30)

if __name__=="__main__": unittest.main()

class TestLegacyUserInterface(unittest.TestCase):
    def test_original_example_has_real_cache_occupancy(self):
        p=AdvancedMemoryAndThermalCore(CFG)
        for addr in [1024,2048,1024,4096,1024,2048,8192,1024]:
            ratio=p.calculate_dynamic_hbm_hit_rate(addr)
        self.assertEqual(ratio,.5)

    def test_original_interconnect_interface(self):
        p=AdvancedMemoryAndThermalCore(CFG)
        latency=p.simulate_interconnect_tier(85)
        self.assertGreater(latency,4)
        self.assertGreater(p.escape_vc_active_count,0)

    def test_original_unrealistic_power_scenario_cannot_falsely_pass(self):
        p=AdvancedMemoryAndThermalCore(CFG)
        x=p.enforce_120w_thermal_limit(35,12.5)
        self.assertTrue(x["Power Cap Met"])
        self.assertLessEqual(x["Total Modeled Power (W)"],120)
        self.assertLess(x["Active Duty Fraction"],1)

    def test_original_fixed_power_impossible_is_flagged(self):
        p=AdvancedMemoryAndThermalCore(CFG)
        x=p.enforce_120w_thermal_limit(135,1)
        self.assertFalse(x["Power Cap Met"])
        self.assertGreater(x["Total Modeled Power (W)"],120)
