import tempfile
import unittest
from pathlib import Path
from sim.v38_trace_ingest import Access, BoundedHBMLRU, iter_csv, iter_pin
from sim.v38_escape_checker import is_acyclic, check_escape, xy_path
from sim.v38_calibration_gate import validate

ROOT = Path(__file__).resolve().parents[1]

class TraceTests(unittest.TestCase):
    def test_real_hit_count_with_reuse(self):
        c = BoundedHBMLRU(2)
        for addr in (0, 64, 0, 64):
            c.submit(Access(0, "P", addr, "R", "HBM_IN"))
        self.assertEqual(c.summary()["hits"], 2)
        self.assertEqual(c.summary()["hit_rate"], 0.5)

    def test_lru_eviction_can_make_repeated_address_miss(self):
        c = BoundedHBMLRU(2)
        for addr in (0, 64, 128, 0):
            c.submit(Access(0, "P", addr, "R", "HBM_IN"))
        self.assertEqual(c.summary()["hits"], 0)

    def test_raw_trace_rejected_at_hbm_boundary(self):
        c = BoundedHBMLRU(2)
        with self.assertRaises(ValueError):
            c.submit(Access(0, "P", 64, "R", "RAW"))

    def test_writeback_on_dirty_eviction(self):
        c = BoundedHBMLRU(1)
        c.submit(Access(0, "GPU", 64, "W", "HBM_IN"))
        c.submit(Access(1, "P", 128, "R", "HBM_IN"))
        self.assertEqual(c.summary()["writebacks"], 1)

    def test_crossing_two_lines(self):
        c = BoundedHBMLRU(4)
        c.submit(Access(0, "GPU", 60, "R", "HBM_IN", 16))
        self.assertEqual(c.summary()["requests"], 2)

    def test_invalid_cache_capacity(self):
        with self.assertRaises(ValueError):
            BoundedHBMLRU(0)

    def test_csv_stream(self):
        trace = list(iter_csv(ROOT / "traces/EXAMPLE_SYNTHETIC_hbm_in.csv"))
        self.assertEqual(len(trace), 8)
        self.assertTrue(all(e.boundary == "HBM_IN" for e in trace))

    def test_pin_import_marked_raw(self):
        trace = list(iter_pin(ROOT / "traces/EXAMPLE_SYNTHETIC_pinatrace.txt"))
        self.assertEqual(len(trace), 3)
        self.assertTrue(all(e.boundary == "RAW" for e in trace))

    def test_pin_rejects_unrecognized(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "t.txt"; f.write_text("UNKNOWN STUFF")
            with self.assertRaises(ValueError):
                list(iter_pin(f))

class RoutingTests(unittest.TestCase):
    def test_escape_xy_all_pairs_has_no_dependency_cycle(self):
        r = check_escape(4, 7)
        self.assertTrue(r["escape_only_dependency_graph_acyclic"])
        self.assertEqual(r["routers"], 28)

    def test_xy_path_manhattan(self):
        p = xy_path(0, 27, 4, 7)
        self.assertEqual(len(p) - 1, 9)
        self.assertEqual(p[-1], 27)

    def test_dependency_checker_detects_cycle(self):
        self.assertFalse(is_acyclic({"a": {"b"}, "b": {"a"}}))

class CalibrationTests(unittest.TestCase):
    def test_proprietary_pdk_missing_blocks_signoff(self):
        r = validate(ROOT / "config/v38_foundry_calibration_template.json")
        self.assertEqual(r["status"], "CALIBRATION_BLOCKED")
        self.assertTrue(r["missing"])

if __name__ == "__main__":
    unittest.main()

class NetworkAdapterTests(unittest.TestCase):
    def test_network_adapter_rejects_writes(self):
        from sim.v38_model_trace_adapter import to_network_trace
        with self.assertRaises(ValueError):
            to_network_trace([Access(0,"P",0x1000,"W","RAW")])

    def test_network_adapter_converts_read_trace(self):
        from sim.v38_model_trace_adapter import to_network_trace
        converted = to_network_trace([Access(0,"GPU",0x1000,"R","RAW",128)], spacing=3)
        self.assertEqual([row[0] for row in converted], [0,3])
        self.assertEqual(converted[0][2], "GPU")
