@echo off
cd /d "%~dp0"
py -3 -m unittest discover -s tests -v
if errorlevel 1 goto failed
py -3 -m sim.run_v35_study --out results\v3_5_study.json
if errorlevel 1 goto failed
echo V3.5 testing complete. Results in results\v3_5_study.json
pause
exit /b 0
:failed
echo A test failed; review the error above.
pause
exit /b 1
